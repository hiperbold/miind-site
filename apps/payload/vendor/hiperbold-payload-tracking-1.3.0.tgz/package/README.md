# @hiperbold/payload-tracking

Plugin de tracking para Payload CMS v3 + Next.js App Router: Tags e Eventos administráveis para Meta Pixel/CAPI, GA4 e Google Ads, com consentimento c15t self-hosted e credenciais criptografadas no banco.

- **Admin decide o quê**: Tags (credenciais por plataforma) e Eventos (gatilhos + destinos) são coleções do Payload.
- **Consentimento decide se**: nada dispara sem a categoria concedida no c15t — nem script de terceiro carrega antes.
- **O módulo decide como**: dedup Pixel/CAPI por `event_id`, outbox idempotente com worker, segredos AES-256-GCM que nunca saem por API.

Estado do projeto: `STATUS.md` · Débitos: `DEBITO.md` · Segurança: `docs/reviews/f6-threat-model.md`.

**Loja virtual (v1.2):** o passo a passo na ordem em que se instala, da migration ao checklist de publicação, está em [`docs/guia-instalacao-ecommerce.md`](docs/guia-instalacao-ecommerce.md). Este README é a referência de cada opção e função.

## Compatibilidade

| Peer | Faixa | Motivo |
|---|---|---|
| `payload` | `^3.85.0` | versão do piloto |
| `next` | `^15.5.0 \|\| ^16.0.0` | piloto em 15.5; template oficial já em 16 |
| `react` | `^19.0.0` | exigência do Payload v3 |

| Ambiente | Mínimo |
|---|---|
| Node | `>=22.11.0` |
| pnpm | `^9 \|\| ^10 \|\| ^11` |
| Banco | testado em Postgres 17.x com o adapter `@payloadcms/db-postgres` (3.85). Outros adapters não são testados. No MongoDB, o índice único de `order_key` (idempotência do pedido) aceita nulo só se for `sparse`, então pode exigir essa opção; o lease atômico por SQL só existe no Postgres e nos demais adapters cai no `update` condicional da Local API |

Este pacote **não** depende de `@payloadcms/db-*` (esses adapters pinam a versão exata do core e prenderiam o consumidor). Só Local API.

## Instalação

Pacote privado, distribuído por tarball (`pnpm pack` → `hiperbold-payload-tracking-<versão>.tgz`):

```bash
pnpm add ./hiperbold-payload-tracking-<versão>.tgz
```

Duas regras do tarball, aprendidas no piloto:

- **Nunca reempacote com a mesma versão.** Mudou qualquer coisa, suba a versão antes do `pnpm pack`. O pnpm não reextrai um tarball de versão que ele já conhece, e o `pnpm-lock.yaml` guarda a integridade do arquivo antigo: o site continua com o código velho ou recusa o lockfile.
- **pnpm 11 ou mais novo:** declare o pacote em `minimumReleaseAgeExclude` no `pnpm-workspace.yaml` do site. Sem isso o pnpm consulta a idade do pacote no registro público, recebe 404 (ele não existe lá) e recusa a instalação.

```yaml
# pnpm-workspace.yaml do site
minimumReleaseAgeExclude:
  - '@hiperbold/payload-tracking'
```

No Docker, o `COPY` do tarball precisa vir antes do `pnpm install` e com o mesmo nome de arquivo do `package.json`.

### 1. Variáveis de ambiente

```bash
# criptografia dos segredos no banco (AES-256-GCM)
PAYLOAD_TRACKING_ENCRYPTION_KEYS='{"k1":"<32 bytes em base64url>"}'
PAYLOAD_TRACKING_ACTIVE_KEY_ID='k1'

# assinatura dos tokens de navegador e do cookie de subject (HMAC-SHA-256)
PAYLOAD_TRACKING_BROWSER_TOKEN_KEYS='{"b1":"<32 bytes em base64url>"}'
PAYLOAD_TRACKING_BROWSER_TOKEN_ACTIVE_KEY_ID='b1'

# banco DEDICADO do c15t (mesma instância do Postgres do site, banco separado)
C15T_DATABASE_URI='postgresql://usuario@host:5432/meusite_c15t'
```

Gerar uma chave de 32 bytes:

```bash
node -e "console.log(require('crypto').randomBytes(32).toString('base64url'))"
```

Os dois keyrings são **independentes** (vault ≠ tokens) de propósito: comprometer um não compromete o outro, e rotacionam separados. Formato: objeto JSON `{keyId: chave}`; o `*_ACTIVE_KEY_ID` aponta qual assina/cifra o novo — as demais permanecem para decifrar/verificar o antigo. Procedimentos de rotação e recuperação: `docs/operacao-chaves.md`.

### 2. Plugin no `payload.config.ts`

```ts
import { trackingPlugin } from '@hiperbold/payload-tracking'

export default buildConfig({
  plugins: [
    trackingPlugin({
      access: { isAdmin: ({ req }) => Boolean(req?.user) },
      consent: {
        transport: 'http',
        backendURL: 'https://seusite.com.br/api/c15t',
        policyId: 'default',
        trustedOrigins: ['https://seusite.com.br'],
      },
      encryption: {},          // defaults: env vars acima
      installationId: 'meusite',
    }),
  ],
})
```

Referência completa das opções (todas validadas em runtime; opção desconhecida é **erro**, e opção inválida **desabilita o plugin** com log — nunca meio-configurado):

| Opção | Default | O que controla |
|---|---|---|
| `access.isAdmin` | — (obrigatória) | quem administra Tags/Eventos; recebe os args de access do Payload |
| `consent.transport` | — (obrigatória) | `http` (first-party via backendURL; único transporte na 1.x) |
| `consent.policyId` | — (obrigatória) | identificador da sua política (informativo; o tipo consultado é `cookie_banner`) |
| `consent.trustedOrigins` | — (obrigatória) | allowlist EXATA de origins do site (1–32) |
| `installationId` | — (obrigatória) | isola criptografia entre instalações (entra no AAD) |
| `browserTokens.ttlSeconds` | `300` | vida do token efêmero do navegador |
| `browserTokens.keyringEnv` / `activeKeyIdEnv` | `PAYLOAD_TRACKING_BROWSER_TOKEN_*` | nomes das env vars do keyring HMAC |
| `encryption.keyringEnv` / `activeKeyIdEnv` | `PAYLOAD_TRACKING_ENCRYPTION_*` | nomes das env vars do keyring AES |
| `jobs.maxAttempts` | `5` | tentativas de entrega antes de `dead` |
| `jobs.retentionDays` | `7` | purge de deliveries terminais |
| `jobs.snapshotTtlHours` | `24` | idade máxima de uma entrega não terminal, contada da criação: passada dela termina `dead` (`snapshot_expirado`) com o snapshot apagado, e nenhuma retentativa é agendada depois dela (passo 6) |
| `jobs.backlogWarnAfterMinutes` | `15` | tempo que uma entrega pronta pode esperar o worker antes de o módulo avisar em log (1 a 1440; passo 6) |
| `jobs.backlogWarnEveryMinutes` | `60` | janela mínima entre dois avisos de backlog no mesmo processo (1 a 1440) |
| `defaultPhoneCountry` | `'BR'` | país do telefone sem `+` (só servidor: `BR`, `PT`, `US`, `CA`, `ES`, `MX`); número nacional com o tamanho do país ganha o código antes do hash (no Brasil, 10 ou 11 dígitos). O navegador ainda não aplica a regra |
| `commerceAdapter` | — | adaptador da loja (E4, D10), só servidor: como produtos e pedidos viram o contrato de comércio, mais a consulta de cliente novo ou recorrente. Criado com `defineCommerceAdapter` (de `/server`); nunca vai à config pública nem ao bundle do navegador. Ver "Adaptador da loja" |
| `feed` | — | feed XML de produtos em `GET {apiBase}/tracking/feed.xml` (Merchant Center e catálogo da Meta). Exige `commerceAdapter` (a opção é recusada sem ele). Campos: `colecao`, `ondePublicado`, `siteUrl` (obrigatórios), `limite`, `cacheSegundos`, `token`, `campoEscopo` + `valorEscopo` (andam juntos), `dominiosImagem`. Sem a opção a rota não existe. Ver "Feeds de produtos" |
| `defaultCurrency` | `'BRL'` | moeda aplicada ao valor monetário que chega sem `currency` (código ISO 4217 existente, em maiúsculas); ver "Contrato de comércio" |
| `privacy.noTrackingPaths` | `[]` | caminhos em que o runtime não carrega script, não dispara e não chama o collect (ex.: `/loja/pagamento/cartao`; até 50; vão na config pública). Ver "Rotas sem tracking" |
| `privacy.stripUrlParams` | `[]` | nomes exatos de parâmetro de URL a remover, somados à lista padrão (até 50; são públicos, vão na config pública); `utm_*`, `gclid`, `gbraid`, `wbraid` e `fbclid` nunca são aceitos aqui |
| `rateLimit.browserPerMinute` | `60` | eventos por subject por minuto no collector |
| `trustedProxies` | `[]` | IPs de proxy confiáveis p/ `x-forwarded-for` (vazio = header ignorado) |
| `enabled` | `true` | `false` devolve a config intacta |

### 3. Backend c15t (rota do próprio site)

O consentimento roda **first-party**, como rota do seu app Next, com banco dedicado na mesma instância Postgres (banco separado, não schema — o introspector do c15t varre o banco inteiro e tropeça nas tabelas do Payload; ver ADR 0001).

```sql
CREATE DATABASE meusite_c15t;
```

```ts
// src/tracking/c15t.ts
import { c15tInstance } from '@c15t/backend'
import { kyselyAdapter } from '@c15t/backend/db/adapters/kysely'
import { migrator } from '@c15t/backend/db/migrator'
import { DB } from '@c15t/backend/db/schema'
import { Kysely, PostgresDialect } from 'kysely'
import pg from 'pg'

const pool = new pg.Pool({ connectionString: process.env.C15T_DATABASE_URI })
const adapter = kyselyAdapter({
  db: new Kysely({ dialect: new PostgresDialect({ pool }) }),
  provider: 'postgresql',
})

export const migrateC15t = async () => {
  const plan = await migrator({ db: DB.client(adapter), schema: 'latest' })
  if ('execute' in plan && typeof plan.execute === 'function') {
    await plan.execute() // sem isto NADA é aplicado — o migrator devolve um plano
  }
}

export const c15t = c15tInstance({
  adapter,
  appName: 'meusite',
  basePath: '/api/c15t',
  trustedOrigins: ['https://seusite.com.br'],
})
```

```ts
// src/app/api/c15t/[[...route]]/route.ts
import { c15t } from '../../../../tracking/c15t.js'

const handler = (request: Request) => c15t.handler(request)
export const DELETE = handler
export const GET = handler
export const OPTIONS = handler
export const PATCH = handler
export const POST = handler
export const PUT = handler
```

Migração: rode `migrateC15t()` uma vez por deploy (script de start ou `instrumentation.ts`). Dependências no site: `@c15t/backend`, `kysely@0.28.17` (a versão da árvore do c15t) e `pg`.

As coleções do plugin no Payload migram pelo fluxo normal do consumidor (`payload migrate` / push do adapter) — o plugin só declara coleções. **Release que acrescenta campo a uma coleção do plugin exige uma migration nova no site** (ver "Atualizando para a 1.2.0" abaixo): o plugin nunca cria nem aplica migration por conta própria.

#### Atualizando para a 1.2.0 (migration no banco do site)

A 1.2.0 acrescenta campos às coleções `tracking-events`, `tracking-tags` e `tracking-deliveries`, todos **opcionais** (colunas que aceitam nulo; a única com valor padrão é `google_ads_validate_only`, `false`): nenhuma linha existente muda e nenhum dado é perdido. Em desenvolvimento (`next dev`), o push do adapter cria as colunas sozinho ao subir. **Em produção não**: o banco precisa da migration antes do primeiro boot com a 1.2.0, senão toda leitura de `tracking-events` e `tracking-tags` falha com "column does not exist". **O que cai sem a migration:** a config pública (`/api/tracking/public-config`), o token e o collect (todos leem a config), o worker da outbox (lê as Tags e a fila `tracking-deliveries`, cuja coluna `order_key` também é nova), a gravação de entregas na fila (`trackServerEvent`, collect) e as telas do Admin das coleções `tracking-events` e `tracking-tags`. O site em si continua de pé, mas **sem tracking nenhum**. **Aviso no boot (S12):** o plugin consulta um campo novo de cada tabela ao subir e, se o banco responder que a coluna não existe, escreve um `ERROR` claro no log ("rode a migration da 1.2.0") sem derrubar o boot. O `trackServerEvent` não rejeita a promessa nesse caso (a server action do lead segue): devolve `{ accepted: 0, reason: 'config_unavailable', message }` e escreve um `WARN` no log do Payload.

1. Com o pacote 1.2.0 instalado, no repositório do site: `pnpm payload migrate:create` (use um nome como `tracking_1_2_0`).
2. Confira o arquivo gerado: só deve haver acréscimo, nada de `DROP` nem `ALTER ... TYPE` de coluna existente:
   - `CREATE TYPE enum_tracking_events_commerce_type AS ENUM (...)` (12 valores) e `ALTER TABLE tracking_events ADD COLUMN commerce_type enum_tracking_events_commerce_type`;
   - `ALTER TABLE tracking_tags ADD COLUMN google_ads_merchant_id varchar`, `google_ads_feed_country varchar` e `google_ads_feed_language varchar`;
   - idempotência do pedido (S2), em `tracking_deliveries`: `ALTER TABLE tracking_deliveries ADD COLUMN order_key varchar` mais um índice único `tracking_deliveries_order_key_idx` (aceita nulo: só eventos de pedido a preenchem; várias linhas nulas são permitidas pelo Postgres);
   - Google Ads pelo servidor (E5), em `tracking_tags`: `google_ads_customer_id varchar`, `google_ads_login_customer_id varchar`, `google_ads_service_account varchar` (campo de entrada, fica sempre nulo: a credencial vive cifrada no cofre), `google_ads_clear_service_account boolean` e `google_ads_validate_only boolean DEFAULT false`; e em `tracking_events_destinations`: `conversion_action_id varchar` e, com o modo da conversão do servidor, `CREATE TYPE enum_tracking_events_destinations_server_conversion_mode AS ENUM ('fonteAdicional', 'offline')` mais `server_conversion_mode enum_tracking_events_destinations_server_conversion_mode` (aceita nulo; nulo vale `fonteAdicional`).
3. Aplique no deploy como as outras migrations do site (`pnpm payload migrate`, ou o `prodMigrations` do adapter no boot). Se o site não usa migration (só push), nada a fazer.
4. Reverter é seguro: as colunas novas podem ficar sem uso (a 1.1.x as ignora).

Site de lead não muda de comportamento: com os campos vazios, a config pública sai idêntica à de antes (mesma `configVersion`).

### 4. Provider no layout

```tsx
// app/(frontend)/layout.tsx
import { Suspense } from 'react'
import { TrackingProvider } from '@hiperbold/payload-tracking/client'

export default function Layout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR">
      <body>
        <Suspense fallback={null}>
          <TrackingProvider apiBase="/api" />
        </Suspense>
        {children}
      </body>
    </html>
  )
}
```

`Suspense` é obrigatório (o provider usa `useSearchParams`). Props: `apiBase` (default do Payload é `/api`) e `nonce` (CSP estrita).

### 5. Banner de consentimento (contrato)

O módulo não traz UI de banner; qualquer banner integra assim:

1. `POST {apiBase}/tracking/browser-token` → antes do consentimento responde `403 {code:'consent_required'}` com `subjectId` no corpo (o cookie `pt_subject` HttpOnly já fica selado).
2. No aceite: `POST /api/c15t/subjects` com `{ subjectId, type: 'cookie_banner', domain, givenAt: Date.now(), preferences: { measurement: true, marketing: true } }`.
3. Avise o runtime, sem reload:

```ts
import { refreshConsent } from '@hiperbold/payload-tracking/client'

await refreshConsent() // após QUALQUER mudança de decisão (aceite, revogação, ajuste parcial)
```

O runtime rebusca o grant e aplica na hora: o primeiro aceite liga scripts e eventos; a revogação corta os disparos imediatamente (`fbq consent revoke` + `gtag consent update`) e o worker cancela entregas pendentes do subject. Recarregar a página continua funcionando como fallback.

Categorias: `measurement` (GA4) e `marketing` (Meta, Google Ads).

### 6. Worker de entregas (obrigatório)

O collector e o `trackServerEvent` só **gravam** a entrega na outbox (`tracking_deliveries`). Quem envia à Meta (CAPI) e ao GA4 (Measurement Protocol) é o worker, e **o plugin não o liga sozinho**: esvaziar a fila é responsabilidade do site. Sem worker, nada sai, nada dá erro e a tabela cresce a cada visita com consentimento. Quando ele enfim roda, o que já passou da janela de `event_time` da Meta termina `dead`.

No Next, o lugar natural é o `instrumentation`, com **import dinâmico dentro do `if`**:

```ts
// src/instrumentation.ts
export async function register() {
  if (process.env.NEXT_RUNTIME === 'nodejs') {
    const { startTrackingWorker } = await import('./instrumentation-node')
    await startTrackingWorker()
  }
}
```

```ts
// src/instrumentation-node.ts
import config from '@payload-config'
import {
  createDeliveryHandler,
  runDeliveryWorkerTick,
  trackingPluginOptionsSchema,
} from '@hiperbold/payload-tracking/server'
import { getPayload } from 'payload'

import { trackingOptions } from './tracking/options' // as MESMAS opções do trackingPlugin(...)

const INTERVAL_MS = 15_000
const MAX_TICKS_PER_ROUND = 25

export const startTrackingWorker = async () => {
  const payload = await getPayload({ config })
  const options = trackingPluginOptionsSchema.parse(trackingOptions)
  const handler = createDeliveryHandler(payload, options)
  let running = false

  setInterval(async () => {
    if (running) return // uma rodada por vez
    running = true
    try {
      for (let i = 0; i < MAX_TICKS_PER_ROUND; i += 1) {
        const result = await runDeliveryWorkerTick(payload, {
          backoffSeconds: 30,
          handler,
          leaseSeconds: 60,
          maxAttempts: options.jobs.maxAttempts,
          snapshotTtlHours: options.jobs.snapshotTtlHours,
        })
        if (result === 'empty') break
      }
    } catch (error) {
      payload.logger.error(`[tracking] rodada do worker falhou: ${String(error)}`)
    } finally {
      running = false
    }
  }, INTERVAL_MS)
}
```

Por que o `import()` dentro do `if` e não um `return` antecipado: com `return`, o webpack compila o resto do arquivo também para o runtime edge e o `next dev` quebra com `Can't resolve 'crypto'`, enquanto o build de produção passa e esconde o problema. Com o `import()` dentro do `if (process.env.NEXT_RUNTIME === 'nodejs')`, o código do worker só entra no bundle do Node.

Confira depois de subir o site: `getOutboxHealth(payload)` deve mostrar `pendingCount` baixo e `oldestPendingAgeMs` de segundos. Rode também `purgeTerminalDeliveries(payload, options.jobs.retentionDays)` de vez em quando (por exemplo, a cada hora) para apagar as linhas terminais antigas.

**Aviso de backlog.** O módulo não depende de você lembrar do worker: a cada collect e a cada `trackServerEvent`, no máximo uma vez por minuto por processo e sem atrasar a resposta, ele procura a entrega pronta mais antiga (`pending`, `retryable` com o backoff vencido ou `leased` com o lease vencido). Se ela espera há mais de `jobs.backlogWarnAfterMinutes` (15), o processo escreve **um** `WARN` no log do Payload (`[payload-tracking] N entrega(s) na outbox esperando há mais de 15 min…`), que aponta **duas causas possíveis**: o worker parado, ou as entregas do Google Ads adiadas pelo limite de 300 requisições por minuto da Data Manager API (o aviso informa quantas estão adiadas agora; com o worker rodando elas voltam aos poucos). Só repete depois de `jobs.backlogWarnEveryMinutes` (60). O aviso aparece enquanto houver visitas ou eventos de servidor; a checagem é em memória e por processo, e falha da consulta nunca afeta a resposta (só vai para o log de debug). Os 15 min existem porque a Meta aceita eventos de até 7 dias, mas o TTL do snapshot (abaixo) é de 24 h: uma parada maior que o TTL perde conversões que a Meta ainda aceitaria, e o aviso é o alarme para agir antes disso.

**Expiração do snapshot.** O padrão é `jobs.snapshotTtlHours` = 24 h, e o tick precisa receber esse valor do config (`snapshotTtlHours: options.jobs.snapshotTtlHours`, como no exemplo; se for omitido vale 24, não o valor que você configurou). Cada tick, antes de arrendar, expira as entregas não terminais (`pending`, `retryable` e `leased` com lease vencido) criadas há `snapshotTtlHours` ou mais: terminam `dead`, com o snapshot apagado e `lastError` = `snapshot_expirado` (ou `snapshot_expirado: <último erro>` quando a entrega já tinha falhado antes). A varredura é em lotes de 100, repetidos enquanto vierem cheios, até 20 por tick; o arrendamento também recusa uma entrega vencida antes de o handler vê-la, e uma falha que agendaria a retentativa para depois do prazo termina `dead` na hora. **Expirar é perder a conversão:** toda expiração em massa escreve um `WARN` com a contagem e o TTL, e uma parada do worker maior que o TTL perde eventos que a Meta ainda aceitaria (até 7 dias). Sem tick, `expireStaleDeliveries(payload, options.jobs.snapshotTtlHours)` (exportada em `/server`) faz a mesma varredura; e, sem worker nenhum, o próprio collect e o `trackServerEvent` disparam essa varredura no máximo uma vez a cada 10 min por processo (a expiração acontece mesmo com o worker parado).

## Uso no Admin

**Tags** (uma por conta de plataforma): plataforma `meta` (Pixel ID + token CAPI + test event code opcionais), `ga4` (Measurement ID + API secret opcional p/ Measurement Protocol), `googleAds` (Tag ID `AW-`). Segredos são write-only: entram em claro no formulário, persistem cifrados, **nunca** voltam por API; remover = checkbox `clear*`. `credentialsConfigured` reflete o estado real do vault.

**Eventos**: `key` técnica imutável (ex.: `orcamento.enviado`), gatilhos em OU (pageView com operadores de URL, linkClick, formSubmit, scroll %, manual, server), frequência `page`/`session`/`always`, e destinos (Tag + nome do evento na plataforma + `conversionLabel` obrigatório em destinos Google Ads + **parâmetros fixos** chave/valor por destino). Loja virtual: o campo opcional **Tipo de comércio** (ver "Tipos de comércio por plataforma"). Vazio é um evento comum, como sempre foi.

**Google Ads pelo servidor (E5)**: a Tag Google Ads ganha o ID da conta, a conta de login (MCC), a conta de serviço (JSON, só escrita) e "Só validar"; o destino Google Ads de um Evento de Compra ganha o ID da ação de conversão da API. Ver "Google Ads pelo servidor (v1.2, E5)".

**Tag Google Ads de loja virtual**: campos opcionais **ID do Merchant Center** (só dígitos, público), **País do feed** (2 letras maiúsculas, vazio usa `BR`) e **Idioma do feed** (2 letras minúsculas, vazio usa `pt`). Entram na configuração pública e só servem à conversão de compra.

**Visualização de página no GA4 não é Evento.** O GA4 conta a página sozinho: o `config` manda a da página em que o gtag carregou e a medição aprimorada manda as das navegações internas. Um destino GA4 com `page_view` contaria cada página duas vezes, então o Admin recusa esse destino. Meta (`PageView`) e a conversão de página do Google Ads continuam sendo Eventos do módulo.

**Grupos E/OU**: cada linha de gatilho de navegador aceita uma condição adicional de página ("clique contém `wa.me` **E** página começa com `/servicos/`"); entre linhas continua valendo OU. Operadores fechados (`começa com`/`igual`/`contém`), sem regex e sem seletor CSS.

## API do navegador (`/client`)

```ts
import { track } from '@hiperbold/payload-tracking/client'

// simples
await track('orcamento.enviado', { origem: 'hero' })

// com Enhanced Conversions e valor (Google Ads)
await track(
  'orcamento.enviado',
  { origem: 'form' },
  {
    user: { email: form.email },            // hasheado ANTES de qualquer envio
    commerce: { value: 15000, currency: 'BRL', transactionId: 'orc-123' },
  },
)
```

- `track()` nunca lança e é no-op sem provider/consentimento.
- **Antes de uma navegação completa, aguarde a função** (`await track(...)`, `await infoEntrega(...)`; link comum, `location.href`, ida a outro layout raiz). A Promise resolve quando as pernas do navegador foram despachadas: o hit do GA4 e a conversão do Ads confirmados pelo gtag (`event_callback`) e o envio ao collect iniciado (`fetch` com `keepalive`; a resposta do collect não é esperada). **O teto é de 1.000 ms no total**, somadas todas as pernas, para bloqueador ou rede lenta: o que passar disso segue em segundo plano e não prende a navegação. Os `fetch` do token e do collect abortam em 10 s. Corpo do collect acima de 60.000 bytes vai sem `keepalive` e então a Promise espera a resposta (dentro do mesmo teto de 1.000 ms); nesse caso, se a página descarrega logo depois, o reenvio após `401` ou `409` (token vencido, configuração trocada) pode se perder, o que se aceita. Sem `await` funciona como sempre, mas a página que sai logo depois pode perder o hit do GA4. Nunca rejeita.
- `user` alimenta o Google Ads (Enhanced Conversions) **e** a Meta (Advanced Matching no Pixel + `em/ph/fn/ln` na CAPI): normalização por plataforma e SHA-256 acontecem **no navegador** (Web Crypto) e PII em claro jamais entra no corpo do collector — o servidor só aceita hashes hex-64.
- `commerce` (valor do lead; contrato completo na seção "Contrato de comércio") chega às três plataformas: conversão do Ads, `custom_data.value/currency` da CAPI e `value/currency/transaction_id` do GA4.
- Consentimento mudou? `refreshConsent()` aplica na hora, sem reload (seção do banner).
- Parâmetros fixos por destino configurados no Admin acompanham cada disparo; valor passado em runtime com a mesma chave vence o fixo.
- Exports: `TrackingProvider`, `track`, `refreshConsent`, `TrackExtras`, `createBrowserClient` e as peças puras da engine.

## API do servidor (`/server`)

```ts
import {
  createTrackingClient,
  readSubjectFromCookieHeader,
} from '@hiperbold/payload-tracking/server'

const subjectId = readSubjectFromCookieHeader(req.headers.get('cookie'))
if (subjectId) {
  const tracking = createTrackingClient(payload, options)
  await tracking.trackServerEvent('orcamento.aprovado', { origem: 'crm' }, {
    subjectId,
    ga: { clientId, sessionId },   // opcional; sem ele destinos GA4 são pulados
    user: { email: lead.email },   // hasheado NO SERVIDOR antes do snapshot (EMQ)
    commerce: { value: 15000, currency: 'BRL', transactionId: 'orc-123' },
  })
}
```

- Só dispara Eventos com gatilho `server`; consentimento é reconsultado por destino; grava na mesma outbox idempotente do collector.
- GA4 via Measurement Protocol **exige** `ga.clientId` explícito ou o `checkoutContext` (nada é inferido); Google Ads só sai pelo servidor na COMPRA, pela Data Manager API (ver "Google Ads pelo servidor (v1.2, E5)"); as demais conversões do Ads são do navegador. Para compra, ver "Compra pelo servidor" logo abaixo.
- `trackServerEvent` não rejeita por falha das plataformas nem por dado recusado: devolve `{ accepted, eventId?, reason?, message? }`. `eventId` (campo opcional, novo na 1.2.0) é o `tx_` do evento de pedido (compra com itens e `transactionId`), o mesmo que saiu para todas as plataformas; guarde-o no pedido (ver "Na página de obrigado", abaixo). Erro do próprio banco ao gravar na outbox (conexão, disco) ainda lança: trate a exceção como falha transitória (no webhook, responda 503 e mantenha o pacote). Quando `accepted` é 0, o `reason` diz se vale tentar de novo:

| `reason` | Significa | Transitório? |
|---|---|---|
| `replayed` | o mesmo evento (mesmo número de pedido) já está na outbox | não: já foi, pode apagar o que guardava para repetir |
| `config_unavailable` | configuração do tracking ou keyring não puderam ser lidos (site sem a migration, banco fora, env ausente) | **sim** |
| `consent_unavailable` | o c15t não respondeu a tempo, caiu ou devolveu registro ilegível em todos os destinos avaliados | **sim** |
| `consent_denied` | o visitante não consente (revogação real) em todos os destinos avaliados | não |
| `no_destination` | nenhum destino chegou a ser avaliado por falta de dado (só GA4 sem `ga.clientId` nem pacote, ou só Google Ads sem ação de conversão da API, fora de Evento de compra ou sem id de clique nem dado do comprador) | não (falta dado; repetir não muda) |
| `event_not_found` | não há Evento ativo com gatilho `server` nessa chave | não |
| `invalid_input` | entrada recusada (campo e regra em `message`), sem subject, pacote inválido ou vencido | não |

  Regra para quem guarda dado para repetir (o pacote do checkout): **só apague com `accepted > 0` ou `reason: 'replayed'`**. Nos transitórios, mantenha e tente de novo; nos demais, mantenha também (o pacote vence sozinho em 7 dias), porque apagar sem a compra na outbox perde a compra.

### Compra pelo servidor (v1.2, D4, D6, D16)

Instalação passo a passo: `docs/guia-instalacao-ecommerce.md`. Os exemplos abaixo chamam o campo do pedido que guarda o pacote de `trackingContext`; a loja de teste o chama `contextoTracking`.

A compra confirmada sai do **servidor**, no webhook do pagamento aprovado, para a Meta (CAPI, mesmo `event_id` do Pixel da página de obrigado) e para o GA4 (Measurement Protocol, com o `client_id` e o `session_id` do checkout). Em quatro passos:

1. **Na criação do pedido**, DEPOIS de o pedido existir (o número entra no pacote), com o `Request` do visitante, capture o contexto e grave o texto no pedido (um campo de texto, cerca de 1 KB):

   ```ts
   const tracking = createTrackingClient(payload, options)
   const trackingContext = await tracking.captureCheckoutContext(request, { transactionId: pedido.numero })
   // grave `trackingContext` (string | undefined) no pedido
   ```

   O texto é opaco: AES-GCM com o keyring de cifra que o módulo já usa (nenhum segredo novo), validade de 7 dias (a janela da Meta) e menos de 2 KB. O dado associado (AAD) amarra o pacote ao tipo `tracking:checkout-context:v1`, ao `installationId` e **ao número do pedido**: o texto de um pedido não abre para outro pedido nem em outra instalação. **O consentimento do visitante (c15t) é consultado na captura e só entra o que a categoria consentida permite:** medição guarda o `client_id` do `_ga` e o `session_id` do `_ga_<ID>` de cada Tag GA4; marketing guarda `_fbp` e `_fbc` (ou o `fbc` do `fbclid` da página), os identificadores de clique dos cookies do próprio Google (`_gcl_aw` gclid e `_gcl_gb` gbraid; nunca UTM; o `_gcl_wb` não é lido, formato não documentado), user agent e IP (só de proxy confiável, `trustedProxies`). Sem nenhuma categoria (ou c15t fora do ar), só o subject, a URL da página sem parâmetros sensíveis (`Referer`, ou `{ pageUrl }` no segundo argumento) e o momento da captura. Cookie de tracking repetido no cabeçalho (`_fbc`, `_fbp`, `_ga`, `_ga_*`, `_gcl_*`) é tratado como ausente. Devolve `undefined` (o pedido segue) quando o visitante não tem o cookie de subject, o número do pedido é inválido ou a captura falha, com aviso no log. Sem o cliente do Payload, `captureCheckoutContext(request, { consent: { backendURL }, installationId, transactionId, ... })` de `/server` faz o mesmo com os nomes de env padrão.

   **Cuidado com o campo do pedido (LGPD):** o texto guarda identificadores do visitante (cifrados, mas ainda dado pessoal). Deixe o campo com leitura e escrita **só de admin e do servidor** (nunca visível ao cliente da loja nem exposto na API pública) e **apague o campo depois que a compra entrar na outbox ou após 7 dias**, o que vier primeiro (depois disso o pacote vence de qualquer forma). "Entrou" é exatamente `accepted > 0` ou `reason === 'replayed'`; em qualquer outro resultado o pacote **fica** (apagar sem a compra na fila perderia a compra para sempre). Exemplo:

   ```ts
   // na coleção de pedidos
   { name: 'trackingContext', type: 'textarea', access: { read: isAdmin, create: isAdmin, update: isAdmin } }

   // no webhook, depois de chamar trackServerEvent: SÓ se a compra entrou (ou já estava lá)
   if (result.accepted > 0 || result.reason === 'replayed') {
     await payload.update({ collection: 'pedidos', id: pedido.id, data: { trackingContext: null }, overrideAccess: true })
   }
   // e um job diário: limpe `trackingContext` de pedidos criados há mais de 7 dias
   ```

   Em pedido com arrays (tentativas, notificações), prefira um `UPDATE` direto só desse campo, com a trava que o resto da loja já usa, a regravar o documento pela Local API.

2. **No webhook do pagamento aprovado**, chame `trackServerEvent` (Evento de tipo compra com gatilho `server`):

   ```ts
   await tracking.trackServerEvent('compra', undefined, {
     checkoutContext: pedido.trackingContext,
     commerce: { currency: 'BRL', items, transactionId: pedido.numero, value: pedido.total },
     occurredAt: pagamento.aprovadoEm, // ISO: a hora real da aprovação
     user: { email, phone, address: { city, country: 'BR', firstName, lastName, postalCode, region } },
   })
   ```

   O pacote só abre com o **mesmo `commerce.transactionId`** da captura (e na mesma instalação); preenche subject, GA4, IP, user agent, `_fbp`, `_fbc` e página conforme o consentimento da captura; campo explícito do chamador (`subjectId`, `ga`, `page`) vence o pacote. **O IP e o user agent da CAPI vêm do pacote, nunca do request do webhook.** Os identificadores de clique do Google ficam só no pacote e no snapshot da perna Google Ads do servidor (E5); nos snapshots da Meta e do GA4 nunca entram. Pacote inválido, adulterado, vencido, de outro pedido ou instalação, sem `commerce.transactionId` na chamada, ou com `occurredAt` anterior à captura em mais de 5 minutos: o evento segue sem ele, com o motivo em `message` e um aviso sem conteúdo no log (sem subject nem pacote, `invalid_input`). Keyring de cifra ausente ou inválido nunca vira exceção: o resultado volta com `message` (`config_unavailable` quando nada pode ser gravado). O consentimento é reconsultado na chamada e de novo na entrega: revogado vira `consent_denied` (nada enfileirado) ou `cancelled` (já na fila); c15t fora do ar, lento ou com registro ilegível vira `consent_unavailable`, que é transitório (ver a tabela de motivos acima). Telefone sem `+` de número nacional (10 ou 11 dígitos no Brasil) ganha o código do país da opção `defaultPhoneCountry` (padrão `BR`) antes do hash, só no servidor; nome e sobrenome (`fn`, `ln`) seguem a regra da 1.1.5, igual no Pixel e na CAPI: minúsculas, sem pontuação, **acentos mantidos** em UTF-8 (a Meta só recomenda o alfabeto a-z e aceita UTF-8; o hash dos sites de lead já instalados não muda); cidade e estado (`ct`, `st`, novos na 1.2.0, só no servidor) usam minúsculas de a a z, sem acento, pontuação nem espaço.

3. **`occurredAt`** vira o `event_time` da CAPI (até 7 dias) e o `timestamp_micros` do Measurement Protocol (até 72 h). Fora da janela só aquela perna cai, com aviso, e as outras seguem; no futuro além de 5 minutos é `invalid_input`. Se a entrega do GA4 só acontece depois de 72 h da hora do evento (fila parada), a entrega termina `dead` com o erro `occurred_at_acima_de_72h`, sem chamar o Measurement Protocol.

4. **Na página de obrigado**, o SSR chama `purchaseEventId(eventKey, numeroDoPedido)` e passa o id ao `compra`/`track` do navegador (`extras.eventId`): o Pixel usa o **mesmo** `event_id` da CAPI do webhook, então a Meta deduplica. Passe também o pacote gravado no pedido, quando ele ainda existir: `purchaseEventId(eventKey, numeroDoPedido, { checkoutContext, installationId })` (ou `tracking.purchaseEventId(eventKey, numeroDoPedido, { checkoutContext })` no cliente criado por `createTrackingClient`). Com o pacote, o id devolvido é o que o servidor fixou na captura, mesmo que a chave ativa do token tenha mudado entre a abertura do pedido e o pagamento (Pix); sem ele deriva com a chave ativa. Faça isso também na tela do Pix. Webhook repetido (mesmo pedido) devolve `reason: 'replayed'` e não gera segunda entrega por destino. **Guarde o `tx_` no pedido ao apagar o pacote (recomendado para lojas).** O resultado de `trackPurchaseFromOrder`/`trackServerEvent` traz `eventId`; quando a compra entrou na outbox (`accepted > 0` ou `replayed`), grave esse id no pedido na mesma atualização que apaga o pacote (campo de texto; o `tx_` é um HMAC e não é dado pessoal). A página de obrigado e a tela do Pix usam, nesta ordem, o id guardado no pedido, o pacote (se ainda existir) e, por último, a derivação com a chave ativa. Sem o id guardado, a página aberta depois do webhook deriva o id com a chave ativa do momento, e a troca de chave entre o webhook e a visita separa o Pixel da CAPI. Na loja de teste: o campo `idCompraTracking` do pedido (`dev/loja/colecoes.ts`), gravado em `registrarCompra` (`dev/loja/tracking.ts`) e lido por `idDaCompra`.

**Falha transitória e reconciliação (recomendado para lojas).** `config_unavailable`, `consent_unavailable` e uma exceção do `trackServerEvent` são falhas passageiras: o pedido já está pago e não pode ser processado de novo, mas a compra não entrou na outbox. Faça duas coisas:

1. **No webhook, responda 5xx** (sem gravar a chave de idempotência da notificação) quando o resultado for transitório. O gateway reenvia; o ramo "já pago" repete só o tracking, e a compra entra na tentativa seguinte. O pedido não é processado duas vezes.
2. **Rode uma reconciliação** (cron, a cada 10 minutos) para o que o gateway não reenviar: pedidos pagos há mais de N minutos cujo pacote ainda está no pedido. Chame o mesmo registro idempotente da compra (o `event_id` é o HMAC do número do pedido): se a compra já estava na outbox, cai em `replayed` e o pacote é apagado; se não, entra agora.

```ts
const result = await tracking.trackServerEvent('compra', undefined, { checkoutContext: pedido.trackingContext, commerce, occurredAt })
if (result.accepted > 0 || result.reason === 'replayed') {
  await limparPacote(pedido.id)
} else if (result.reason === 'config_unavailable' || result.reason === 'consent_unavailable') {
  return new Response(null, { status: 503 }) // o gateway reenvia; não grave a chave da notificação
}

// reconciliação: pedidos pagos há mais de 15 min com o pacote ainda preenchido, criados nos últimos 7 dias
const parados = await payload.find({
  collection: 'pedidos',
  where: { and: [
    { status: { equals: 'pago' } },
    { trackingContext: { exists: true } },
    { aprovadoEm: { less_than_equal: new Date(Date.now() - 15 * 60_000).toISOString() } },
    { createdAt: { greater_than: new Date(Date.now() - 7 * 86_400_000).toISOString() } },
  ] },
})
for (const pedido of parados.docs) await registrarCompra(pedido) // a mesma função do webhook
```

Na loja de teste: `dev/loja/reconciliacao.ts` (`reconciliarComprasPagas`, `limparPacotesVencidos` e `manutencaoDoTracking`, que roda as duas) e o 503 do webhook em `dev/loja/webhook.ts`. Pedido pago sem pacote (visitante que nunca viu o banner) não tem como enviar a compra do servidor: a loja de teste escreve um aviso no log, sem dado pessoal.

**Cuidados da loja com o pedido (S17).**

- **O `transactionId` é único na instalação inteira.** É dele que saem o `event_id` da compra, a idempotência da outbox (`order_key`) e a chave que amarra o pacote ao pedido. Dois pedidos com o mesmo `transactionId` (de lojas diferentes, de bancos que reiniciam o contador, ou um prefixo esquecido) viram UMA compra: o segundo cai em `replayed` e a conversão se perde. Em instalação com **várias lojas**, ponha o prefixo da loja (`loja-a-1001`); o `transactionId` aceita até 128 caracteres.
- **Apague o pacote do checkout dos pedidos com mais de 7 dias, pagos ou não (LGPD).** O pacote guarda IP, user agent e cookies de tracking cifrados; depois de 7 dias a CAPI recusa o evento e não há motivo para guardá-lo. Pedido abandonado ou recusado nunca chega a apagá-lo pelo caminho da compra. Rode junto da reconciliação:

```ts
// a cada rodada do agendador, depois da reconciliação das compras pagas
await payload.update({
  collection: 'pedidos',
  data: { trackingContext: null },
  overrideAccess: true,
  where: {
    and: [
      { trackingContext: { exists: true } },
      { createdAt: { less_than_equal: new Date(Date.now() - 7 * 86_400_000).toISOString() } },
    ],
  },
})
```

- **Não ligue pedido de visitante sem login a uma conta existente só pelo e-mail digitado.** Quem digita o e-mail de outra pessoa entraria na conta dela (histórico, endereço, dado pessoal). Ligue o pedido à conta autenticada; o visitante com e-mail já cadastrado fica com o pedido sem conta. O "cliente novo ou recorrente" (`historicoDoCliente`) cai no e-mail do pedido e continua funcionando.
- **GA4 pulado (S8).** Se o destino GA4 do Evento não tem `client_id` (o pacote não trouxe o cookie `_ga`, a medição estava negada na captura, ou não há pacote nem `ga` explícito), a perna GA4 não sai e o resultado traz uma nota em `message`, com um `WARN` agregado no log (contagem, nunca identificador).

**Dados do comprador (D7).** `user` aceita e-mail, telefone (E.164, com `+`), nome, sobrenome, cidade, estado, CEP e país. Tudo é normalizado e hasheado (SHA-256) **no servidor** antes de gravar; a CAPI recebe `em`, `ph`, `fn`, `ln`, `ct`, `st`, `zp`, `country` e `external_id`. A normalização segue a Meta: cidade em minúsculas sem acento nem espaço, estado em sigla minúscula (nome de estado brasileiro vira sigla), CEP só dígitos no Brasil, país ISO-2 minúsculo.

**Info de pagamento (D8).** Evento de tipo `add_payment_info` com gatilho `server`, chamado por `trackServerEvent` na criação do pagamento, sai para o GA4 (MP, com `payment_type` de `commerce.paymentType`) e para a Meta (`AddPaymentInfo`). O `event_id` nasce do número do pedido, então **o mesmo pedido gera um só `add_payment_info`; a segunda tentativa (outro cartão, depois de uma recusa) não reenvia** (cai em `replayed`). Chame o `trackServerEvent` depois de soltar qualquer trava do pedido: ele consulta o c15t por HTTP e não deve segurar a criação de pagamentos.

**Loja de teste (`dev/`, só com `LOJA_PERMITIR_SIMULACAO=1`).** Segue este guia de ponta a ponta: `dev/loja/tracking.ts` captura o pacote na criação do pedido, manda `add_payment_info` na criação do pagamento (id por pedido: nova tentativa é replay) e a compra no webhook (também no ramo `ja-pago`, idempotente); o `add_payment_info` roda depois de soltar a trava de pagamento do pedido. Apaga o pacote (SQL com a trava do pedido) só quando a compra entrou na outbox ou já estava lá; falha transitória mantém o pacote e o webhook responde 503 sem gravar a chave da notificação, com `reconciliarComprasPagas` para o que o gateway não reenviar. Falha de tracking nunca desfaz o pedido pago. A página de obrigado e a tela do Pix leem o pacote do pedido no servidor e calculam o id com ele (`idDaCompra`; o pacote nunca vai ao navegador, só o id) e a tela do Pix recebe esse id do SSR e, ao ver o pedido pago, chama `compra()` (com teto de 2,5 s, para quem pagou nunca ficar preso) e vai ao obrigado (a marca por pedido barra a repetição). O seed cria Tags de dev GA4 (`G-LOJATESTE01`) e Google Ads (`AW-000000000`) com ids fictícios. Provas: `tests/integration/loja-compra-servidor.test.ts` e `tests/unit/loja/compraPix.test.ts`.

### Google Ads pelo servidor (v1.2, E5)

A conversão de compra do Google Ads também pode sair do **servidor**, pela Data Manager API (`events:ingest`), com a mesma chamada de `trackServerEvent`/`trackPurchaseFromOrder` do webhook. Serve para o Pix pago com a tela fechada: o navegador não estava lá para mandar a conversão. A conversão do navegador continua como está. O Google **só deduplica dentro da MESMA ação de conversão**, pelo `transaction_id` (o id opaco `tx_` da compra, não o número do pedido; ver a tabela "Quando sai"); por isso há dois modos por destino (campo *Modo da conversão do servidor (Google Ads)*):

| Modo | Ação de conversão | Deduplica com o gtag? | Quando usar |
|---|---|---|---|
| **`fonteAdicional`** (padrão; destino sem modo vale isto) | A **mesma** do rótulo do gtag (ação do tipo Website/tag). O servidor entra como "fonte de dados adicional" da tag (multi-source). | **Sim**, pelo `transaction_id`. | Recomendado: a compra do navegador e a do servidor viram uma só. |
| **`offline`** | Uma ação **separada**, do tipo `UPLOAD_CLICKS` ("Website (importar de cliques)"). | **Não.** Se a ação do navegador também conta compra, a compra conta **em dobro**. | Só quando a ação do navegador NÃO conta compra (por exemplo, a compra só existe pelo servidor) ou quando a conta não tem a fonte adicional. O Admin avisa no log ao salvar. |

Fontes (consultadas em 2026-10-07): https://developers.google.com/data-manager/api/devguides/events/google-ads/online/send-events, https://developers.google.com/data-manager/api/devguides/events/google-ads/offline/send-events, https://developers.google.com/data-manager/api/devguides/events/send-events, https://developers.google.com/data-manager/api/reference/rest/v1/events/ingest e https://support.google.com/google-ads/answer/16542291.

**Sem a configuração abaixo, nada muda**: a perna de servidor do Ads só existe para o destino com o ID da ação de conversão da API preenchido.

**Pré-requisitos externos (uma vez por conta)**
1. Um projeto no Google Cloud com a **Data Manager API** ativada e uma **conta de serviço** (papel `Service Usage Consumer`).
2. Adicionar o e-mail da conta de serviço como usuário da conta do Google Ads, ou da conta gerente (MCC) que a administra.
3. **Modo `fonteAdicional`**: a ação de conversão do gtag (compra) deve ser uma ação de site criada **por código** (Google tag ou Tag Manager); a documentação não oferece fonte adicional para ação importada do Google Analytics nem por URL. O ID que vai no destino é o **ID numérico dessa mesma ação**, que não é o rótulo: no Google Ads, vá em Metas > Conversões > Resumo, abra a ação e leia o parâmetro **`ctId`** na URL do navegador. **Modo `offline`**: a ação é outra, do tipo `UPLOAD_CLICKS`, e o ID dela vai no destino.
4. **Disponibilidade e lista de liberação.** A fonte adicional da tag é um recurso **beta** do Google ("se você não consegue acessar, pode não estar disponível para você ainda"). A documentação consultada não cita lista de liberação para o Google Ads (a lista é citada só para vendas em loja física e para eventos do GA4), mas, **se a conta recusar a requisição por permissão ou recurso indisponível, o Filipe pede ao Google (gerente da conta) a liberação para a conta**. Valide antes com *Só validar* (abaixo).
5. **14 dias de teste.** Os dados de fonte adicional da Data Manager API **não entram no lance** nos primeiros 14 dias da ação ("usados para relatório e diagnóstico, mas não impactam o lance"); isso não vale para o dado da Google tag, que segue valendo. O valor enviado pelo servidor **substitui** o valor que a tag gravou para o mesmo pedido: mantenha a mesma moeda e o mesmo cálculo. O Google recomenda enviar em até 24 horas do evento.

**Configuração no Admin**
- **Tag Google Ads**: *ID da conta do Google Ads (API)* (10 dígitos, sem hífen; é a conta operadora), *ID da conta gerente (login, API)* (opcional, a MCC onde a conta de serviço tem acesso; vazio quando o acesso é direto), *Conta de serviço (JSON, write-only)* e *Só validar*. O JSON é cifrado no cofre como o token da Meta e **nunca sai**: nem por API, GraphQL, log, snapshot, erro nem pela configuração pública. Remover = o checkbox *Remover conta de serviço*. O Admin recusa JSON que não seja uma chave `service_account`, sem repetir o conteúdo.
- **Destino Google Ads do Evento de Compra**: *ID da ação de conversão (API do servidor)* (só dígitos) e *Modo da conversão do servidor (Google Ads)* (vazio = `fonteAdicional`). Escolher o modo sem o ID é recusado (o ID é o da mesma ação do rótulo do gtag, no modo padrão). O Admin recusa o campo em destino que não seja Google Ads, em Evento que não seja de Compra ou em Tag sem o ID da conta. Um destino com perna de servidor por Tag e por pedido: dois destinos com o ID da ação na mesma Tag Ads no mesmo Evento colidiriam na idempotência da outbox (`tagId:eventId`) e só o primeiro sairia, então o Admin recusa salvar (um destino a mais na mesma Tag, sem o ID da API, só do navegador, continua valendo).
- O ID da ação e o da conta **não vão** à configuração pública (o navegador não precisa deles; a `configVersion` dos sites instalados não muda): o servidor os lê do banco.

**Quando sai.** Só a **compra**, só pelo servidor, com consentimento de **marketing** (reconsultado na entrega: revogado vira `cancelled`). Entram no corpo:

| Campo da API | De onde vem |
|---|---|
| `destinations[0]` | `operatingAccount` = ID da conta da Tag; `loginAccount` = conta gerente (se houver); `productDestinationId` = ID da ação |
| `events[0].eventSource` | `WEB` nos dois modos (na fonte adicional a documentação aceita só `WEB`; no offline também manda `WEB`) |
| `events[0].transactionId` | o id opaco `tx_` da compra (o mesmo `event_id` da Meta e o mesmo `transaction_id` do gtag; ver "`transaction_id` opaco" abaixo). Obrigatório na `fonteAdicional`; opcional no `offline` (sai quando existe) |
| `events[0].eventTimestamp` | `occurredAt` (a aprovação do pagamento), em UTC |
| `events[0].conversionValue` e `currency` | o valor e a moeda do comércio (o `value` calculado dos itens, igual nas três plataformas) |
| `events[0].adIdentifiers` | `gclid` e `gbraid` do pacote do checkout (cookies `_gcl_aw` e `_gcl_gb`, só com consentimento de marketing na captura) |
| `events[0].userData.userIdentifiers` | e-mail e telefone do `user`, hasheados no servidor (SHA-256, hex): e-mail em minúsculas, sem espaços e, em gmail, sem pontos nem `+sufixo`; telefone em E.164 (número nacional ganha o código de `defaultPhoneCountry`) |
| `events[0].userProperties.customerType` | `NEW` ou `RETURNING`, quando o comércio traz o `customerType` (D9) |
| `consent` | `adUserData` e `adPersonalization` `CONSENT_GRANTED` (a perna só existe com marketing concedido) |
| `encoding` | `HEX` |
| `validateOnly` | `true` quando a Tag está em *Só validar* |

**Sem id de clique e sem e-mail nem telefone** do comprador a API não tem como atribuir: a perna **não é enfileirada**, o resultado traz uma nota em `message` e um `WARN` no log (a conversão do navegador não muda). Os destinos Google Ads do servidor são lidos do banco **uma vez, antes de gravar qualquer entrega**; se a leitura falha, só a perna do Ads cai (aviso no log e nota em `message`, Meta e GA4 seguem; sem outra perna o motivo é `config_unavailable`, e repetir a chamada enfileira só o Ads). `wbraid` não é capturado: o Google não documenta um cookie de primeira parte para ele (só `_gcl_aw` e `_gcl_gb` aparecem na lista de cookies), então o pacote do checkout nunca o preenche e ele não conta como sinal para enviar a conversão (débito D-POS-019).

**Autenticação.** Conta de serviço, sem dependência nova: o módulo assina um JWT RS256 com `node:crypto` (escopo `https://www.googleapis.com/auth/datamanager`, `aud` `https://oauth2.googleapis.com/token`; `iat` 30 s no passado, para tolerar relógio adiantado, e `exp` 1 hora depois do `iat`) e o troca por um token OAuth2. As duas chamadas ao Google (troca do token e `events:ingest`) têm **tempo limite de 10 s** (estourar é transitório) e a resposta é lida até **64 KB**. Os endereços do Google só podem ser trocados em teste (`NODE_ENV=test`); fora dele a troca é ignorada, com aviso. O token fica em cache **em memória**, por processo, até 60 s antes de vencer; trocas simultâneas viram uma só. A chave privada só existe dentro dessas funções.

**Limites.**
- **2.000 eventos por requisição** (teto da API): hoje a entrega é de **1 evento por requisição** (uma entrega da outbox por compra). O mapeamento aceita lote e recusa mais de 2.000; o envio em lote não é usado.
- **300 requisições por minuto por projeto do Google Cloud**: o handler tem um limitador de janela deslizante **por processo**. Passou do teto, a entrega volta para a fila (`retryable`, `lastError` `limite_de_taxa_ads_api`) com `nextAttemptAt` na próxima janela livre, **sem somar tentativa** (o worker aceita o resultado `{ defer }` do handler, genérico: Meta e GA4 não mudam) e não bate na API. Se a espera passa do prazo do snapshot, a entrega expira. Vários processos de worker no mesmo projeto somam, então o teto real é 300 vezes o número de processos. Uma loja que chegue perto de 300 compras por minuto precisa de lote (não implementado).

**Erros.** Transitório (volta para a fila): rede, HTTP 5xx, 408, 429, 401 (o token em cache é descartado e a próxima tentativa troca por um novo) e os status `UNAVAILABLE`, `DEADLINE_EXCEEDED`, `INTERNAL`, `UNKNOWN`, `ABORTED` e `RESOURCE_EXHAUSTED`. Permanente (`dead`, sem repetir): o resto (400, 403, 404, payload recusado, permissão negada) e recusa do endpoint de token (`invalid_client`, `invalid_scope` etc.). `invalid_grant` é tratado como transitório nas duas primeiras tentativas (costuma ser relógio do servidor fora de hora) e permanente da terceira em diante. Os IDs da conta, da conta de login e da ação são conferidos de novo (só dígitos) antes de montar o corpo; fora do formato é permanente (`customer_id_invalido`, `login_customer_id_invalido`, `conversion_action_id_invalido`). Credencial ausente: `sem_conta_de_servico`; ilegível: `credencial_ilegivel`. O código gravado em `lastError` é montado só de nomes de enum do Google (por exemplo `ads_api_400_INVALID_ARGUMENT_INVALID_SHA256_FORMAT`); a mensagem do Google nunca é copiada, porque pode repetir o valor recusado. A API é *fast-fail*: um evento inválido derruba a requisição inteira.

**Validar a credencial antes de valer (`validateOnly`).**
1. Marque *Só validar* na Tag. Cada conversão do servidor vai com `validateOnly: true`: o Google confere o corpo, a permissão e a ação de conversão e **não grava conversão nenhuma**. Entrega `delivered` = o Google aceitou o corpo (só erros voltam). **Cuidado: nada é gravado.** A entrega concluída fica marcada com `lastError` `somente_validacao`, o log emite um `WARN` agregado (o primeiro na hora, depois um por 10 minutos, com a contagem) dizendo que as conversões não estão sendo gravadas, e `getOutboxHealth().validateOnlyDeliveredCount` conta as entregas assim ainda no registro. Esquecer a opção ligada em produção perde conversões.
2. Para validar sem esperar uma compra, rode o helper de `/server` num script seu, com o JSON da conta de serviço lido de um arquivo seu (a Tag nunca o devolve):

```ts
import { readFileSync } from 'node:fs'
import { validateGoogleAdsApiSetup } from '@hiperbold/payload-tracking/server'

const result = await validateGoogleAdsApiSetup({
  conversionActionId: '1234567890',
  customerId: '1112223334',
  loginCustomerId: '9998887776', // opcional
  serviceAccountJson: readFileSync('conta-de-servico.json', 'utf8'),
})
// { ok: true, requestId } ou { ok: false, kind: 'permanent' | 'transient', code: 'ads_api_403_PERMISSION_DENIED...' }
```

3. Desmarque *Só validar* para valer. O helper também usa `validateOnly`, com um evento sintético (e-mail de exemplo e `transactionId` `validacao-<hora>`).

Provas: `tests/unit/providers/googleAdsApi/*` (corpo contra o formato e os exemplos de hash da documentação, JWT verificado com chave gerada no teste, classificação de erros e limitador) e `tests/integration/google-ads-api.test.ts` (uma única entrega `googleAdsApi` por compra com o `transactionId` do gtag, sem marketing não enfileira, revogação cancela, erros, limite, segredo e validações do Admin; rede 100% simulada).

### Adaptador da loja (v1.2, D9, D10)

O módulo não conhece o modelo de dados da sua loja. O **adaptador** é a única ponte: você diz como um produto vira item do contrato, como um pedido pago vira compra e como achar os pedidos pagos de um cliente. O módulo faz o resto: acha o Evento de compra, preenche cliente novo ou recorrente, hasheia o comprador e enfileira. Sem adaptador configurado nada muda (sites de lead).

O exemplo abaixo é o da loja de teste (`dev/loja/adaptador.ts`), no modelo da Repersonalize: produtos com variantes (SKU) e faixas de preço por quantidade; pedidos com snapshot do comprador e dos itens.

```ts
// adaptador.ts (só servidor)
import { defineCommerceAdapter } from '@hiperbold/payload-tracking/server'

export const adaptador = defineCommerceAdapter<Produto, Variante, Pedido>({
  // item do contrato: id = SKU da variante (igual ao feed); itemGroupId = id do produto (D17)
  produtoParaItem: (produto, variante) => ({
    ...(produto.marca ? { brand: produto.marca } : {}),
    category: produto.categoria,
    id: variante?.sku ?? String(produto.id),
    itemGroupId: String(produto.id),
    name: produto.nome,
    price: variante?.preco ?? produto.preco, // preço de catálogo; a faixa por quantidade é do carrinho
    ...(variante ? { variant: variante.rotulo } : {}),
  }),

  // pedido PAGO: comércio, comprador (hasheado no servidor), hora da aprovação e número do pedido
  pedidoParaCompra: (pedido) => ({
    commerce: {
      currency: pedido.moeda ?? 'BRL',
      discount: pedido.desconto,
      items: pedido.itens.map((item) => ({ // snapshot do pedido, nunca o catálogo de hoje
        id: item.variante || String(item.produto),
        itemGroupId: String(item.produto),
        name: item.nome,
        price: item.precoUnitario,
        quantity: item.quantidade,
        ...(item.rotuloVariante ? { variant: item.rotuloVariante } : {}),
      })),
      shipping: pedido.frete,
      value: pedido.total,
    },
    // e-mail, telefone e endereço do snapshot do pedido (a versão completa está em dev/loja/adaptador.ts)
    ...(pedido.comprador?.email ? { comprador: { email: pedido.comprador.email } } : {}),
    ...(pedido.pagamento?.aprovadoEm ? { occurredAt: new Date(pedido.pagamento.aprovadoEm).toISOString() } : {}),
    transactionId: `LT-${pedido.numero}`, // o MESMO número da captura do pacote do checkout
  }),

  // uma linha de feed por variante (a opção `feed` publica o XML, ver "Feeds de produtos")
  produtoParaFeed: (produto) =>
    (produto.variantes?.length ? produto.variantes : [undefined]).map((variante) => ({
      availability: 'in_stock',
      brand: produto.marca ?? 'Minha Loja',
      condition: 'new',
      description: produto.descricao ?? produto.nome,
      id: variante?.sku ?? String(produto.id), // o mesmo id dos eventos
      imageLink: new URL(produto.imagem ?? '/sem-imagem.png', 'https://minhaloja.com.br').toString(),
      itemGroupId: String(produto.id),
      link: `https://minhaloja.com.br/produto/${produto.slug}`,
      price: variante?.preco ?? produto.preco,
      productType: produto.categoria,
      title: variante ? `${produto.nome} (${variante.rotulo})` : produto.nome,
    })),

  // cliente novo ou recorrente (D9)
  historicoDoCliente: {
    campoCliente: 'cliente', // id do cliente no pedido (relação)
    campoData: 'pagamento.aprovadoEm', // quando o pagamento foi aprovado
    campoEmail: 'comprador.email', // usado quando o pedido não tem cliente vinculado; GRAVE-O em minúsculas
    // campoEscopo: 'loja', // lojas multi-tenant: só pedidos com o mesmo valor deste campo contam
    colecao: 'loja-pedidos',
    ondePago: { status: { equals: 'pago' } },
  },
})
```

```ts
// payload.config.ts: o adaptador entra por uma opção do plugin
trackingPlugin({ /* ... */ commerceAdapter: adaptador })

// onde você usa o módulo: o tipo do produto, da variante e do pedido sai do próprio adaptador
const tracking = createTrackingClient<typeof adaptador>(payload, options)

// webhook do pagamento aprovado: monta pelo adaptador, acha o Evento de compra e envia
const result = await tracking.trackPurchaseFromOrder(pedido, { checkoutContext: pedido.trackingContext })

// SSR da página do produto: item pronto para as funções do navegador
const item = tracking.itemFromProduct(produto, variante) // lança se o adaptador devolver item inválido

// SSR da página de obrigado: cliente novo (true), recorrente (false) ou undefined (não se sabe)
const novo = await tracking.isNewCustomer(pedido)
// ... e no navegador: compra({ eventId, items, transactionId, customerType: novo === undefined ? undefined : novo ? 'new' : 'returning' })
```

- **Contrato estrito, nada de texto digitado (D2).** O retorno de cada função é o contrato do módulo (`CommerceItem`, `CommerceInput`). Texto que o cliente digita na personalização (ou observação do pedido) não tem campo ali e **nunca deve ser lido pelo adaptador**: se aparecer num item, o comércio inteiro é recusado com o campo e a regra, nunca o valor (`trackPurchaseFromOrder` devolve `invalid_input` e não envia; `itemFromProduct` lança). Use os dados do **snapshot do pedido** (nome, preço e variante da hora da compra), não o produto de hoje.
- **`trackPurchaseFromOrder(pedido, context)`.** Chama `pedidoParaCompra`, valida o comércio, acha o Evento de tipo Compra com gatilho `server` (único por site, D16), preenche `customerType` quando o adaptador não o informou e chama `trackServerEvent` com `checkoutContext`, `occurredAt` e `user`. `context` aceita `checkoutContext`, `ga`, `page` e `subjectId`. Nunca rejeita: devolve o mesmo `ServerTrackResult` (`event_not_found` sem Evento de compra; `invalid_input` sem adaptador, com adaptador que lança, com comércio inválido (a compra NÃO sai e o motivo vai com `logger.error`, não aviso) ou com `occurredAt` inválido; `config_unavailable` sem a migration). A regra do pacote do checkout (apagar só com `accepted > 0` ou `replayed`) continua valendo.
- **Cliente novo ou recorrente (D9).** `historicoDoCliente` conta pedidos **pagos** do mesmo cliente (por id do cliente; sem cliente, pelo e-mail do pedido) nos **540 dias anteriores ao pagamento do pedido atual** (padrão do Google), **excluindo o pedido atual** (por isso o pedido precisa ter `id`; o tipo do pedido do adaptador exige `id: number | string`). `ondePago` é um filtro Payload obrigatório e não vazio, e `and`/`or` não podem ser listas vazias nem conter filtro vazio (a opção é recusada ao subir). `campoData` é a data de aprovação do pagamento, nos pedidos da coleção e também no pedido atual (texto ISO ou `Date`): a janela é `campoData >= pagamento - 540 dias` e `campoData < pagamento`, **estritamente anterior**, então um pedido pago no mesmo instante não conta. Pedido atual sem data de pagamento (ou com data inválida): a janela termina agora. **E-mail:** o módulo aparta e põe em minúsculas o e-mail do pedido atual e consulta só esse valor, então o `campoEmail` precisa ser **gravado normalizado (aparado e em minúsculas)** na criação do pedido (a loja de teste faz isso em `dev/loja/servico.ts`); e-mail gravado com maiúsculas não é achado. **Lojas multi-tenant:** `campoEscopo` (opcional) é o campo do pedido (ex.: `loja`, `tenant`) cujo valor tem de ser igual ao do pedido atual; sem ele o histórico olha todos os pedidos da coleção, e **se a coleção tem o campo `tenant` do plugin multi-tenant e `campoEscopo` não foi informado, o histórico fica desligado** (`isNewCustomer` devolve `undefined`, a compra sai sem `customerType`, e um `ERROR` vai ao log uma vez por coleção). Com `campoEscopo` configurado e o pedido atual sem o valor, não se sabe (sem `customerType`), nunca cruza lojas. A consulta roda só no servidor, com `limit: 1`, `select` só do id e `overrideAccess: true` explícito (a Local API do Payload ignora o access control; é aceitável porque nada além do booleano sai: nunca devolva nem registre documentos). Vira `customer_type` no GA4 e `new_customer` no Google Ads. **Falha da consulta** (coleção errada, banco fora): a compra segue sem `customerType`, com um aviso no log sem dado pessoal. Pedido sem id, sem cliente e sem e-mail: também sem `customerType`, com **um** aviso no log por processo (sem dado pessoal), para o adaptador com defeito não passar em silêncio. Um `customerType` informado pelo adaptador vence a consulta. Como a janela termina no pagamento do pedido atual, reprocessar um pedido antigo depois de uma compra posterior do mesmo cliente continua dando cliente novo.
- **Feed (E6).** `produtoParaFeed` devolve `FeedProduct[]` (`id`, `itemGroupId`, `title`, `description`, `link`, `imageLink`, `availability`, `price`, `salePrice?`, `brand`, `condition`, `productType`, `gtin?`, `mpn?`; preço em unidade principal): uma linha por variante, com o **mesmo `id`** do item dos eventos (D17). A opção `feed` publica essas linhas em XML: ver "Feeds de produtos".
- **Validação de forma.** A opção é conferida ao subir o plugin: as três funções são obrigatórias, campo desconhecido é erro e `historicoDoCliente` exige `colecao`, `campoData`, `ondePago` que de fato filtre (não vazio, sem `and`/`or` vazio) e `campoCliente` ou `campoEmail` (nomes de campo em notação de ponto; `campoEscopo` é opcional). O formato do `historicoDoCliente` tem uma só definição: o schema `customerHistorySchema`, de onde sai o tipo `CustomerHistory`. O objeto passa intacto e **nunca é serializado**: não vai à config pública, ao collect nem ao navegador, e o adaptador só existe no export `/server`.
- **Na loja de teste** (`dev/`): `dev/loja/tracking.ts` chama `trackPurchaseFromOrder`; a página do produto monta o item com `itemFromProduct`; a página de obrigado e a tela do Pix recebem `customerType` por `isNewCustomer` (via `dadosDaCompra`). Provas: `tests/unit/server/commerceAdapter.test.ts`, `tests/unit/loja/tracking.test.ts`, `tests/integration/adaptador-loja.test.ts` (novo, recorrente, não pago, 541 e 539 dias, por e-mail, só booleano) e `tests/integration/loja-compra-servidor.test.ts`.

### Feeds de produtos (v1.2, E6, D11)

O módulo publica um feed XML (RSS 2.0 com o namespace `g:` do Google) a partir do `produtoParaFeed` do adaptador. **Um arquivo só serve o Google Merchant Center e o catálogo da Meta.** Sem a opção `feed` a rota não existe (404) e nada muda para sites de lead.

```ts
trackingPlugin({
  commerceAdapter: adaptador, // obrigatório: é o produtoParaFeed dele que monta cada linha
  feed: {
    colecao: 'produtos', // coleção do Payload que o adaptador lê
    ondePublicado: { publicado: { equals: true } }, // filtro Payload: só o que está publicado entra
    siteUrl: 'https://minhaloja.com.br', // absoluta; link e imagem relativos são resolvidos contra ela
    // opcionais:
    limite: 10_000, // itens (linhas), padrão 10.000, máximo 50.000
    cacheSegundos: 3_600, // padrão 1 h; sem token o mínimo é 300 (0 só vale com token)
    token: process.env.FEED_TOKEN, // feed privado (mín. 16 caracteres); texto ou lista de textos; o valor vem do ambiente, nunca do código
    campoEscopo: 'loja', valorEscopo: 'loja-a', // multi-tenant: filtro fixo do tenant que este feed serve (andam juntos)
    dominiosImagem: ['cdn.minhaloja.com.br'], // se informado, só imagens destes hosts (incluindo o do próprio site, se as imagens são dele)
  },
})
```

**URL a cadastrar** (a mesma nos dois): `https://minhaloja.com.br/api/tracking/feed.xml` (com token: `…/feed.xml?token=<valor>`, ou o endereço limpo com usuário qualquer e o token na senha, ver "Token").

- **Merchant Center:** Produtos, fonte de dados nova, "Buscar de um arquivo agendado" (URL acima, formato XML/RSS).
- **Meta (Gerenciador de Comércio):** Catálogo, Fontes de dados, "Feed de dados", URL agendada (a Meta documenta feed XML com o namespace `g:`; a página consultada cita XML Atom e a de RSS 2.0 não carregou, então a aceitação do RSS 2.0 fica a confirmar no primeiro envio).
- **Token declarado e vazio desliga o feed (S15).** `token: process.env.FEED_TOKEN` com a variável esquecida vira `undefined`: o feed **não** fica público; ele fica desligado (503), com um erro claro no boot. Vale também para texto vazio e lista vazia. Feed público é só o que nem declara a chave `token`.
- **Token opcional.** Com `token`, o endpoint exige o token por `?token=` **ou** por HTTP Basic (usuário qualquer, senha = token; o Merchant Center e a Meta aceitam usuário e senha na busca agendada, e assim o token sai da URL e do log de acesso) e responde 401 sem ele (comparação em tempo constante). `token` aceita um texto ou uma lista (até 5): para trocar sem derrubar, ponha o novo ao lado do antigo, atualize o Merchant Center e a Meta e tire o antigo. Sem `token` o feed é público, e por isso só leva dado público e o cache tem piso de 300 s (um robô não refaz a montagem a cada pedido). Com `?token=` o valor vai na URL e aparece em log de acesso do servidor e de proxy: prefira Basic, use um valor só para o feed e troque-o se vazar. Se a chave `token` nem é declarada, o feed fica **público**; se é declarada e a variável de ambiente não existe, o feed fica desligado (503), ver "Token declarado e vazio" acima. Ao subir, o servidor loga uma linha informativa dizendo se o feed está **PÚBLICO** ou **PROTEGIDO** (nunca o token); confira-a no ambiente de produção.
- **Rascunhos.** Se a coleção tem `versions.drafts`, o módulo junta sempre `_status: published` (AND) ao `ondePublicado`. O `ondePublicado` não pode ser vazio nem ter `and`/`or` vazio (o plugin recusa: um filtro que casa tudo publicaria o catálogo inteiro).
- **Multi-tenant.** **Um feed serve uma loja.** Em instalação com vários tenants na coleção de produtos, informe `campoEscopo` (campo do produto, ex. `loja`) e `valorEscopo` (o tenant deste feed); entra como filtro AND fixo. Sem ele o feed publicaria os produtos de todos os tenants. O módulo trava isso sozinho no caso comum: se a coleção tem o campo `tenant` do `@payloadcms/plugin-multi-tenant` e `campoEscopo` não foi informado, o feed **fica desligado** (503, e um `ERROR` no log, uma vez). Coleção que chama o campo de tenant de outro nome não é detectada: nela o `campoEscopo` é por sua conta. Para duas lojas, duas instalações (cada uma com o seu feed e o seu `siteUrl`).
- **Link e imagem.** O `link` precisa ter a mesma origem (esquema, host e porta) do `siteUrl`; o `imageLink` precisa ser https, de qualquer host, ou só dos hosts de `dominiosImagem` quando a lista existe (o host do próprio site também tem de estar nela, se as imagens são dele). `http:` só vale fora de produção (`NODE_ENV !== 'production'`), então em produção o `siteUrl` deve ser https. Linha que não cumpre sai do feed, com o motivo no aviso.
- **O que sai.** Só os campos do `FeedProduct`, de produtos lidos com `overrideAccess: false` e sem usuário (a leitura pública da coleção da loja, mais o `ondePublicado`; um cookie de admin na requisição não amplia nada), `depth: 0`, paginados. Por linha: `id`, `title` (até 150), `description` (sem HTML, até 5.000), `link`, `image_link`, `availability` (`in_stock`, `out_of_stock`, `preorder`, `backorder`), `price` (`12.50 BRL`, moeda `defaultCurrency`), `sale_price` (só se menor que o preço), `brand`, `gtin` (só com dígito verificador correto), `mpn`, `identifier_exists` `no` quando não há GTIN nem MPN, `condition` (padrão `new`), `item_group_id` (o id do produto, agrupa as variantes) e `product_type`. Imagens adicionais e `google_product_category` não fazem parte do `FeedProduct` nesta versão.
- **Item inválido fica fora, nunca derruba o feed.** Sem id, título, preço, link ou imagem válidos, id ou `item_group_id` acima de 50 caracteres (id não é cortado: um id alterado deixaria de ser o dos eventos), disponibilidade desconhecida, `id` repetido, linha que não é um objeto ou `produtoParaFeed` que lança (nunca vira 503): o item sai e **um** aviso agregado vai ao log por montagem (motivo e contagem, até 3 ids de exemplo, nunca o texto do erro). Sem marca, sem descrição (usa o título), GTIN ou MPN inválido e preço promocional que não é menor entram com aviso. Textos acima do limite são cortados em caracteres inteiros (nunca no meio de um UTF-8).
- **Cache.** Em memória, por processo, por `cacheSegundos` (sem token, no mínimo 300). É marcado como velho quando um produto da coleção é criado, alterado ou apagado (hooks `afterChange` e `afterDelete`, acrescentados aos da coleção sem tocar nos seus; uma segunda marcação 5 s depois cobre a leitura feita antes do commit da transação; erro do feed nunca quebra a gravação do produto). **Velho não é apagado (stale-while-revalidate):** o primeiro pedido refaz o feed e espera por ele; os outros pedidos, enquanto isso, recebem o último resultado bom, e no máximo uma montagem roda por vez por processo. **Montagem que falha fica guardada por 60 s**: nesse tempo o último resultado bom continua saindo (ou 503, se nunca houve um), sem bater de novo na coleção. **O último bom tem idade máxima em falha (S13):** o maior entre 10 × `cacheSegundos` e 1 h, com teto de 24 h; passado isso o feed responde 503. **Erro de acesso (Forbidden, 403) vira 503 na hora e não serve cache**: a permissão da coleção foi revogada. A coleção é lida por id crescente (`id > último`, páginas de 200), não por deslocamento, então produto criado ou apagado no meio não repete nem pula outro. **Com vários processos (réplicas), cada um tem o seu cache e só percebe a mudança feita em outro quando o prazo vence**: reduza `cacheSegundos` se o atraso importa. Mudança em dado que o produto só referencia (ex.: renomear uma categoria) também só aparece quando o prazo vence. Os cabeçalhos são `ETag`, `Last-Modified` (só anda quando o conteúdo muda) e `Cache-Control` (`public` sem token, `private` com token); `If-None-Match` e `If-Modified-Since` respondem 304.
- **Se a coleção não pode ser lida sem usuário**, a montagem falha e avisa no log (o feed não passa por cima do acesso da coleção): o endpoint responde 503 se não há resultado bom guardado; se há, ele continua saindo enquanto durar a falha guardada (60 s por tentativa).
- **Validação real pendente.** O gate E6 foi cumprido por teste estrutural contra a especificação publicada (`tests/fixtures/feed.ts`: XML bem formado e atributos obrigatórios no formato certo). A validação no Merchant Center e a aceitação no catálogo da Meta ficam para quando as contas existirem. Especificações: https://support.google.com/merchants/answer/7052112 e https://support.google.com/merchants/answer/160589 (Google) e https://developers.facebook.com/docs/commerce-platform/catalog/fields/ (Meta). A Meta lista `availability` como "in stock"/"out of stock"; o feed usa os valores do Google (`in_stock`), que ela deve aceitar, a confirmar no primeiro envio.
- **Na loja de teste** (`dev/`): `produtoParaFeed` em `dev/loja/adaptador.ts`, `feed` em `dev/tracking-options.ts` (com `LOJA_FEED_TOKEN` o feed exige token), URL `http://localhost:3000/api/tracking/feed.xml`. Provas: `tests/unit/server/feedXml.test.ts`, `tests/unit/endpoints/feed.test.ts` e `tests/integration/feed-loja.test.ts` (inclui o teste de igualdade de ids entre o feed e `itemFromProduct`, E6-04).

### Worker de entregas

Passo obrigatório da instalação: ver "6. Worker de entregas" acima, com o exemplo completo.

```ts
import {
  createDeliveryHandler,
  getOutboxHealth,
  runDeliveryWorkerTick,
} from '@hiperbold/payload-tracking/server'

// a cada N segundos (cron, setInterval do processo, etc.)
await runDeliveryWorkerTick(payload, {
  backoffSeconds: 30,
  handler: createDeliveryHandler(payload, options),
  leaseSeconds: 60,
  maxAttempts: options.jobs.maxAttempts,
  snapshotTtlHours: options.jobs.snapshotTtlHours,
})
// monitoração: idade do backlog e contagens por estado
const health = await getOutboxHealth(payload)
```

O tick expira o que passou de `snapshotTtlHours`, arrenda uma entrega (inclusive lease vencido de processo morto), reconsulta consentimento, entrega (Meta CAPI / GA4 MP), reagenda transitórios com backoff (nunca para depois do prazo do snapshot) e destrói o snapshot em qualquer estado terminal.

**O que o handler devolve tem significado.** Sem retorno (Meta, GA4), a entrega conclui como sempre. Um objeto muda o destino da linha: `{ defer: { code, until } }` devolve a entrega para a fila em `until` (no mínimo 1 s depois de agora; data inválida vira agora mais `backoffSeconds`), sem somar tentativa, com `code` em `lastError` (é o que o Google Ads faz acima do limite de 300 requisições por minuto); `{ note }` conclui e grava a nota em `lastError`. Qualquer outro valor (texto, número) conta como sem retorno. Entrega concluída sem nota sai com `lastError` vazio. Se o seu site embrulha o handler (por exemplo, para medir tempo ou logar), **repasse o resultado**: `handler: (d) => inner(d)` ou `return inner(d)`. Um wrapper que faz `await inner(d)` sem `return` descarta o `defer` e a entrega é dada como concluída sem ter sido enviada. A conclusão só vale sobre linha ainda `leased`: se outro worker já levou a entrega a um estado final, a escrita tardia é descartada. Uma entrega adiada que passa de `jobs.backlogWarnAfterMinutes` desde a criação conta no aviso de backlog.

## Contrato de comércio (v1.2)

Um contrato só descreve o comércio no navegador (`track(..., { commerce })`), no servidor (`trackServerEvent(..., { commerce })`), no corpo do collect (`context.commerce`) e no evento canônico. Tipos: `CommerceData`, `CommerceInput` e `CommerceItem` (exports `/client`, `/server` e `/types`). Todos os campos são opcionais, então o formato antigo dos leads (`{ value, currency?, transactionId }`) segue valendo. O navegador valida com um validador leve, sem zod (o bundle do cliente não carrega o zod); o servidor usa o schema zod, e um teste com a mesma tabela de casos garante que os dois concordam.

- **Pedido:** `currency` (ISO 4217, `^[A-Z]{3}$`), `value`, `shipping`, `tax`, `discount`, `transactionId`, `coupon`, `paymentType`, `shippingTier`, `customerType` (`new` ou `returning`), `itemListId`, `itemListName`, `searchTerm` e `items`.
- **Item:** `id` (obrigatório), `name`, `variant`, `brand`, `category` a `category5`, `coupon`, `affiliation`, `listId`, `listName`, `itemGroupId`, `price`, `quantity` (inteiro de 1 a 10000), `discount` e `index`. Campo fora dessa lista invalida o comércio.
- **Limites:** até 200 itens, e o comércio inteiro até 40 KB serializado. Dinheiro em unidade principal (reais), finito e não negativo, arredondado para centavos; textos de 1 a 100 caracteres; `transactionId` de 1 a 128 caracteres imprimíveis, sem `@` nem caractere de controle. Dado inválido é **recusado com o motivo, nunca truncado**. O corpo do collect tem teto de 96 KB (acima disso, HTTP 413 com o código público `invalid_request`).
- **Comércio inválido nunca derruba o evento, exceto na compra, que não sai.** Formatos legados são normalizados antes de validar (`transactionId` passa por `String()`, `currency` sobe para maiúsculas, número em texto vira número, `null` vira ausente). Se ainda assim o comércio for inválido, o evento sai **sem** o comércio em todas as pernas (Pixel, gtag, Ads e collect), e o motivo (campo e regra, nunca o valor) vai para o `console.error` no navegador, ou para o log e para `message` no resultado do `trackServerEvent`. **A compra pelo servidor é a exceção:** Evento do tipo Compra sem comércio válido com itens e `transactionId` (`trackServerEvent` e `trackPurchaseFromOrder`) **não sai** e devolve `invalid_input` com o campo e a regra, registrado com `logger.error`. Sem itens a compra perderia o `event_id` determinístico do pedido e repetir a chamada duplicaria a conversão; corrija o adaptador ou o pedido e reenvie. O collect (o transporte) continua estrito: responde só `invalid_request` e registra o motivo em um log agregado (no máximo uma linha por minuto por processo, só depois de token válido e rate limit).
- **Moeda padrão:** com `value`, `shipping`, `tax`, `discount` ou algum `price` de item e sem `currency`, vale a opção `defaultCurrency` (`BRL`). Sites de lead que mandam `value` sem moeda continuam funcionando.
- **Personalização nunca entra (D2).** A garantia real é estrutural: o item é estrito e não tem campo para texto digitado pelo cliente. A heurística é só rede de segurança. Nos textos de **catálogo** (id, nome, marca, categorias, variante, cupom, listas, grupo, afiliação, tipo de pagamento e de frete) só **e-mail completo** (`local@dominio.tld`, inclusive com o `＠` de largura total) é recusado: "Caneca @ Casa" e "Kit 2 arroba" passam. No texto **digitado pelo visitante** (`searchTerm`) vale a heurística ampla (`@`, `＠`, `(at)`, `[at]`, "arroba"). Telefone (10 a 13 dígitos, com separadores e dígitos de largura total, fora anos e datas) é recusado só em `searchTerm`, `coupon` e `variant`. Nome de produto com ISBN ou EAN passa. Nas `properties`, o valor de texto com cara de e-mail ou telefone é descartado sozinho (o evento segue, com aviso). O valor **numérico** também cai quando o nome da chave sugere telefone (palavra inteira `telefone`, `phone`, `celular`, `whatsapp`, `fone`, `tel` ou `mobile`, sem diferenciar maiúsculas) ou quando o inteiro tem forma de telefone brasileiro (10 ou 11 dígitos com DDD de 11 a 99, e com 11 só se o terceiro é 9; ou 12/13 dígitos começando com 55 e seguindo a mesma regra). Timestamp em ms, valor monetário e id curto ficam. A regra vale no navegador e no collect.
- **`transaction_id` opaco no Google (S1).** Na COMPRA, o `transaction_id` enviado ao Google Ads (gtag da página de obrigado e Data Manager API, nos dois modos, `offline` inclusive) e ao GA4 (Measurement Protocol) é o id `tx_` da compra, o mesmo `event_id` da Meta, igual nos dois lados. Motivo: o número do pedido costuma ser sequencial e o `AW-ID/rótulo` da conversão é público (vai na config pública); quem os lê poderia disparar conversões com os números dos próximos pedidos e anular as reais pela deduplicação. O `tx_` é um HMAC que só o servidor calcula. O **número do pedido real** continua no GA4 como parâmetro de evento `order_number` (só servidor, no Measurement Protocol) e na Meta como `order_id`; para conciliar uma compra do Google com o pedido, procure pelo `tx_` (`purchaseEventId(eventKey, transactionId)`) ou pelo `order_number` no GA4. Eventos que não são compra mantêm o `transactionId` do comércio.
- **`event_id` da compra (D5), por HMAC.** O id de uma compra com `items` e `transactionId` é `tx_` mais o base64url de um HMAC-SHA256 de `eventKey` e `transactionId`, com chave derivada (HKDF-SHA256, `info` `tracking:purchase-event-id:v1`) do keyring do token de navegador. Quem sabe o número do pedido não consegue forjá-lo. O `trackServerEvent` deriva sozinho; a página de obrigado gera o mesmo no SSR com `purchaseEventId(eventKey, transactionId)` (de `/server`) e passa ao `track(..., { commerce, eventId })` (`extras.eventId`). O navegador nunca deriva. O collect confere: id `tx_` que não bate com o HMAC do `eventKey` e do `transactionId` do corpo é `invalid_request`, e evento cuja configuração só tem gatilho `server` não aceita corpo do navegador. A compra repetida (recarregar a página de obrigado, webhook reenviado) cai no replay do collect e na idempotência da outbox; o navegador trata `replayed` como sucesso silencioso e o `trackServerEvent` devolve `reason: 'replayed'`. Lead (sem itens) mantém id aleatório. **Troca da chave ativa do token (S2):** o id depende da chave ativa; para a compra não mudar de id no meio do caminho, o pacote do checkout guarda o `tx_` de cada Evento de comércio do servidor calculado na captura, e `trackServerEvent` usa o id do pacote quando alguma chave do keyring o confirma (sem pacote, ou pacote gravado antes desse campo, deriva como antes). Além disso a outbox também é idempotente por destino + chave do Evento + número do pedido (coluna `order_key`): reenviar o mesmo pedido com outro id responde `replayed` em vez de criar segunda entrega. A página de obrigado e a tela do Pix **podem passar o pacote gravado no pedido** a `purchaseEventId(eventKey, transactionId, { checkoutContext, installationId })` (no cliente: `purchaseEventId(eventKey, transactionId, { checkoutContext })`): se o pacote abre para aquele pedido e traz o id daquele Evento confirmado por alguma chave do keyring, o id devolvido é esse, o mesmo do servidor, e a troca de chave não separa o Pixel da CAPI nem o gtag do Data Manager (`fonteAdicional`). Pacote ausente, vencido, de outro pedido, adulterado ou sem o id: deriva com a chave ativa, como antes. **Atenção:** se o site apaga o pacote do pedido depois de enviar a compra (a orientação da LGPD acima), a página de obrigado aberta depois disso não tem pacote e deriva com a chave ativa; nesse caso guarde o `tx_` no pedido ao apagar o pacote (o `eventId` do resultado de `trackPurchaseFromOrder`/`trackServerEvent`) e use-o primeiro na página; sem o id guardado, a página deriva com a chave ativa e, para esses pedidos, vale trocar a chave ativa do token em horário de pouco movimento (ver `docs/operacao-chaves.md`).
- **Snapshot da outbox:** subiu de 16 KB para 64 KB. É só validação do Payload (a coluna é `varchar` sem tamanho), então **não há migração** no site. O teto de 40 KB do comércio deixa folga para o envelope cifrado (base64, 4/3 do tamanho). O envelope é medido antes de gravar: acima de 64 KB a recusa é limpa (`invalid_request` no collect, `message` no servidor), nunca um erro 500. O snapshot guarda só a URL da página, sem título nem referrer.

### Tipos de comércio por plataforma (E2)

O campo **Tipo de comércio** do Evento define o nome padrão do evento em cada plataforma e liga a tradução do comércio (itens, pedido) para ela. O `eventName` do destino, quando preenchido, **sempre vence**. Sem tipo (leads), nada muda. O tipo vai na config pública e, por isso, entra no hash da `configVersion` (só quando preenchido: site de lead mantém a versão de antes).

| Tipo (Admin) | GA4 | Meta | Google Ads |
|---|---|---|---|
| Ver lista | `view_item_list` | exige `eventName` (personalizado) | conversão (label) |
| Selecionar item | `select_item` | exige `eventName` | conversão |
| Ver produto | `view_item` | `ViewContent` | conversão |
| Busca | `search` | `Search` | conversão |
| Lista de desejos | `add_to_wishlist` | `AddToWishlist` | conversão |
| Adicionar ao carrinho | `add_to_cart` | `AddToCart` | conversão |
| Remover do carrinho | `remove_from_cart` | exige `eventName` | conversão |
| Ver carrinho | `view_cart` | exige `eventName` | conversão |
| Iniciar checkout | `begin_checkout` | `InitiateCheckout` | conversão |
| Info de entrega | `add_shipping_info` | exige `eventName` | conversão |
| Info de pagamento | `add_payment_info` | `AddPaymentInfo` | conversão |
| Compra | `purchase` | `Purchase` | conversão |

- **Meta sem evento padrão:** destino Meta com um tipo marcado "exige `eventName`" é recusado no Admin, com a mensagem "Destino Meta sem nome do evento…", até você informar o nome (evento personalizado, `trackSingleCustom` no Pixel). Vale também ao trocar só o tipo de um Evento já gravado. Destino GA4 ou Google Ads no mesmo Evento não exige nada.
- **GA4 (E2-02):** o gtag (navegador) e o Measurement Protocol (servidor) montam os parâmetros pela **mesma função**: `currency`, `value`, `transaction_id`, `coupon`, `shipping`, `tax`, `payment_type`, `shipping_tier`, `customer_type`, `item_list_id`, `item_list_name`, `search_term` e `items` (`item_id`, `item_name`, `affiliation`, `coupon`, `discount`, `index`, `item_brand`, `item_category` a `item_category5`, `item_list_id`, `item_list_name`, `item_variant`, `price`, `quantity`). Campo ausente não vai. `value` ausente com **todos** os itens com preço é calculado: Σ(`price` × `quantity`, quantidade ausente vale 1) − `discount` do pedido, nunca negativo, em centavos; item sem preço desliga o cálculo (um total parcial seria pior que nenhum). O desconto do pedido só entra nesse cálculo: o GA4 não tem parâmetro de desconto no evento.
- **GA4, a compra não sai pelo gtag (D4, D16):** o tipo `purchase` nunca é disparado pelo gtag no navegador (o GA4 não deduplica gtag com Measurement Protocol) e **também não passa pelo collect**: a compra do GA4 sai só pelo servidor, no **Measurement Protocol**, quando o seu webhook de pagamento chama `trackServerEvent` com o contexto do checkout (ver "Compra pelo servidor" acima). Precisa de **API secret** na Tag GA4. Os outros 11 tipos continuam só pelo gtag.
- **Admin (D16):** destino Meta com nome resolvido `Purchase` (sem diferenciar maiúsculas) ou GA4 com `purchase` só é aceito em Evento do tipo Compra; em outro tipo (ou sem tipo) o Admin recusa ao criar ou editar, e a mensagem cita as três saídas: marcar o tipo Compra, renomear o evento do destino ou desligar o destino. Só o que a edição **traz de novo** é recusado (destino novo, renomeado ou com o tipo trocado saindo de Compra): um Evento já salvo antes da regra continua editável (nome, frequência, gatilhos) com o mesmo destino, e a gravação passa com um aviso no log.
- **Compra no navegador (collect):** Evento de tipo compra vindo do navegador exige `eventId` com prefixo `tx_` válido (HMAC de `purchaseEventId`) e `commerce.transactionId`; sem isso o collect responde `invalid_request`. Com eles, o collect responde `202` com `accepted: 0` e **não grava nada** (D16): o valor vindo do navegador pode ser alterado pelo visitante, e quem chegasse primeiro travaria o id. No navegador a compra segue só para o Pixel (mesmo `eventID` da CAPI) e para o Google Ads. A recusa vale também por **configuração legada**: Evento sem tipo cujo destino Meta resolve para `Purchase` (sem diferenciar maiúsculas) ou cujo destino GA4 resolve para `purchase` (nome do destino, padrão do tipo ou a própria key do Evento) tem essa perna recusada no collect (`202`, sem enfileirar, com uma nota agregada no log), independentemente de `commerceType`.
- **Meta (E2-03):** Pixel e CAPI usam a **mesma função**: `value`, `currency`, `order_id` (número do pedido), `content_ids`, `contents [{ id, quantity, item_price }]` (quantidade ausente vale 1; preço ausente não vai), `content_type: 'product'`, `num_items` (soma das quantidades); em `view_item`, `content_name` e `content_category` do primeiro item; em `search`, `search_string`. O mesmo `eventID` vai no Pixel e na CAPI. Atenção: o Pixel de um evento com `transactionId` agora também leva `order_id` (antes só a CAPI levava).
- **Google Ads (E2-04):** a conversão leva `value`, `currency` e `transaction_id` em qualquer tipo (na compra, o `transaction_id` é o id opaco `tx_`, ver "`transaction_id` opaco"). Na **compra** vão também `items [{ id, price, quantity }]`, `aw_merchant_id` (só com o Merchant Center na Tag), `aw_feed_country` e `aw_feed_language` (padrão `BR` e `pt`; só com itens), `discount` (desconto do pedido) e `new_customer` (`customerType` `new` vira `true`, `returning` vira `false`, ausente não vai). Sem o Merchant Center, o resto do carrinho vai mesmo assim. O `id` do item precisa ser o código do produto no feed do Merchant Center.

- **`value` calculado, igual nas três plataformas (D17).** `value` ausente, com TODOS os itens com preço, vira Σ(`price` × `quantity`) menos o `discount` do pedido (mínimo 0, em centavos), em GA4, Meta (Pixel e CAPI) e Google Ads, por uma função só. Só nos tipos em que o GA4 define valor (`view_item`, `add_to_wishlist`, `add_to_cart`, `remove_from_cart`, `view_cart`, `begin_checkout`, `add_shipping_info`, `add_payment_info`, `purchase`); nunca em `view_item_list`, `select_item` e `search`, nem em Evento sem tipo. O `value` informado sempre vence.
- **GA4: teto de 25 parâmetros por evento.** O corte considera os parâmetros fixos do transporte (2 reservados) e as chaves de comércio presentes (`items` conta 1). O excedente são sempre as properties (nunca o comércio) e sai um aviso agregado (no console em desenvolvimento; no log do Payload na entrega do servidor).

### Funções prontas de comércio (E2-05)

Exportadas por `/client`, no mesmo padrão do `track` (chame de qualquer client component, com o `TrackingProvider` montado). Cada função dispara **todos os Eventos da config cujo "tipo de comércio" é o da ação**, qualquer que seja a key, pelo gatilho **manual** de cada um: **exatamente um disparo por Evento**, não importa quantos gatilhos manuais ele tenha, e sem atingir Evento de outro tipo (nem de lead) que compartilhe a key de um gatilho. Sem Evento do tipo configurado, sem consentimento ou sem provider: não faz nada e não dá erro. Cada função devolve uma Promise: **antes de uma navegação completa, aguarde a função** (`await infoEntrega(...)`), senão o GA4 pode perder o hit. Chamadas feitas antes de o provider ficar pronto (token e config vêm da rede, então um `verProduto` no efeito de montagem chega antes dele) ficam numa fila de até 20 e saem na ordem quando ele entra (fila cheia descarta a mais antiga; chamada nova durante a drenagem entra no fim); a que esperou mais de 15 s (visitante que só consentiu depois) é descartada, e a fila é esvaziada quando o provider desmonta (consentimento recusado). A página (URL, título e referrer) é a da **hora da chamada**, não a da drenagem, e cada item drenado tem o mesmo teto de 1.000 ms (uma chamada lenta não prende os seguintes). Chamada feita numa rota de `noTrackingPaths` é descartada, não fica na fila.

| Função | Tipo |
|---|---|
| `verLista({ itemListId?, itemListName?, items })` | `view_item_list` |
| `selecionarItem({ itemListId?, itemListName?, item })` | `select_item` |
| `verProduto(item, { value?, currency?, coupon? }?)` | `view_item` |
| `buscar(termo, { items? }?)` | `search` |
| `adicionarListaDesejos(item)` | `add_to_wishlist` |
| `adicionarCarrinho(item \| items)` | `add_to_cart` |
| `removerCarrinho(item \| items)` | `remove_from_cart` |
| `verCarrinho({ items, value?, coupon? })` | `view_cart` |
| `iniciarCheckout({ items, value?, coupon? })` | `begin_checkout` |
| `infoEntrega({ items, shippingTier, value?, coupon? })` | `add_shipping_info` |
| `compra({ eventId, transactionId, items, value?, shipping?, tax?, discount?, coupon?, customerType?, user? })` | `purchase` |

Tipos exportados: `ItemComercio`, `ItensComercio`, `ListaComercio`, `OpcoesComercio`, `VerListaInput`, `SelecionarItemInput`, `CarrinhoInput`, `InfoEntregaInput`, `CompraInput`. `info de pagamento` não tem função de cliente: sai do servidor (D8).

- **`compra` exige `eventId` com prefixo `tx_`**, vindo do SSR (`purchaseEventId(eventKey, transactionId)` de `/server`). Sem ele (ou com comércio inválido), `console.error` e **nada sai**: nem Pixel, nem Google Ads, nem collect. Vale também para o `track()` de um Evento cujo tipo é compra. O comércio da compra precisa ter `transactionId`; sem ele também é `console.error` e nada sai. O id é derivado da key do Evento, então **o Admin aceita um só Evento de compra por site** (um segundo é recusado, com a mensagem de usar vários destinos no mesmo Evento: Meta, GA4 e Google Ads).
- **Compra no máximo 1 vez por pedido, no navegador (E2-06).** O módulo marca o pedido no `localStorage` (chave `pt_tx:<key do Evento>:<id tx_>`; com storage indisponível vale a memória da página). A marca só é gravada **depois que uma perna de navegador (Pixel ou Google Ads) disparou de fato**: sem consentimento, com erro de hash ou sem `crypto.subtle` nada sai e nada é marcado, então o pedido sai quando o visitante conceder e recarregar. Enquanto a primeira chamada espera, uma segunda do mesmo pedido é barrada. A segunda chamada com o mesmo id não sai em perna nenhuma do **Evento de compra**; compra sem `tx_`, sem comércio válido ou já enviada tira só o Evento de compra da ocorrência, e os outros Eventos que casam com ela (um PageView da Meta na mesma URL, por exemplo) seguem normalmente. **A frequência do Evento de compra é ignorada no navegador** (a marca por pedido já garante uma vez); Evento com tipo de comércio nasce com frequência "Sempre" no Admin ("Uma vez por página", o padrão do Admin, vale como "não escolhida" na criação; para outra frequência, edite depois de criar).
- `user` (Enhanced Conversions) é hasheado no navegador e nunca vai ao collect. Item só com ids e rótulos de catálogo; texto de personalização nunca entra (D2).

### Rotas sem tracking (E2-06)

`privacy.noTrackingPaths`: lista de caminhos (até 50) em que o runtime **não carrega gtag nem fbevents, não dispara nada e não chama o collect**. Casa por segmentos inteiros, a partir do começo: `/loja/pagamento/cartao` cobre também `/loja/pagamento/cartao/erro`, mas não `/loja/pagamento/cartao-pix`; `*` vale por um segmento (`/conta/*/cartao`); cada segmento é decodificado antes de comparar (`/loja/%63artao` é `/loja/cartao`) e um segmento que não decodifica (`%zz`) conta como excluído, por segurança; `/`, padrão só de curingas (`/*`) e padrão com segmento vazio (`//`) são recusados. Vai na config pública (só padrões de rota). Navegação SPA para uma rota excluída com os scripts já carregados: nada dispara ali, o GA4 é desligado (`ga-disable`) e o Pixel é revogado até sair da rota. Ao sair, o consentimento atual é reaplicado ao gtag (uma recusa dada dentro da rota excluída não fica "granted").

**Passe a mesma lista ao provider:** `<TrackingProvider noTrackingPaths={['/loja/pagamento/cartao']} />`. Com a prop, o provider checa a rota **antes** de buscar token e config: em rota excluída ele não faz nenhuma requisição a `/api/tracking/*` e não carrega script; ao navegar para fora da rota, sobe normalmente. Sem a prop, a lista só chega pela config pública, depois do token (a checagem do orquestrador continua valendo, mas a requisição do token já aconteceu). Se a prop e a lista da config divergem (inclusive prop ausente com a config trazendo lista), o provider escreve **um** `console.warn` com a diferença, só fora de produção.

**Isto é a segunda camada.** A primeira é a página de cartão ficar num layout **sem `TrackingProvider`** (grupo de rotas com layout raiz próprio) ou ser aberta por **navegação completa**: scripts carregados antes continuam na memória da aba. Não confie só na opção para PCI.

### URL limpa

Antes de qualquer saída, a URL da página, o referrer e o `href` do clique perdem credenciais (`user:senha@`), os parâmetros sensíveis e o fragmento sensível.

- **Por nome (sem diferenciar maiúsculas):** o nome contém `token`, `email`, `e_mail`, `mail`, `senha`, `password`, `passwd`, `secret`, `cpf`, `cnpj`, `phone`, `telefone`, `celular`, `whatsapp`, `jwt`, `signature`, `session` ou `auth`; ou é exatamente `code`, `state`, `key`, `apikey`, `api_key`, `pass`, `rg` ou `tel`. Sufixo `[...]` (inclusive `%5B%5D`) casa pela base. `privacy.stripUrlParams` soma nomes exatos; os nomes são **públicos** (vão na config pública que o navegador lê), então não ponha segredo ali.
- **Por valor:** parâmetro cujo valor parece e-mail é removido, qualquer que seja o nome. Telefone NÃO é detectado no valor (id de campanha do Google Ads, EAN, pedido e `msclkid` têm 10 a 13 dígitos); telefone na URL só é coberto pelo nome do parâmetro (`phone`, `telefone`, `celular`, `whatsapp`, `tel`).
- **Atribuição:** `utm_*`, `gclid`, `gbraid`, `wbraid` e `fbclid` nunca saem; neles só o VALOR é apagado, e só se for e-mail.
- **Fragmento:** removido só se tiver par sensível ou valor sensível. `#contato` fica intacto.
- A limpeza roda no navegador, de novo no collect, no `trackServerEvent` (campo opcional `page: { url }`) e na entrega da CAPI (`event_source_url`).
- **gtag:** quando a URL ou o referrer precisaram de limpeza, o módulo entra em modo sobrescrito: `gtag('set', { page_location, page_referrer })` com valores limpos antes de cada `config`, a cada navegação e antes de um evento do módulo, até o fim da vida da página (mesmo que as URLs seguintes estejam limpas). O `set` só é empurrado quando o par limpo muda desde o último e há uma perna gtag para disparar (a navegação sempre empurra, para o page_view automático do GA4): cem scrolls na mesma página não geram cem `set`. Sem nada sensível, o gtag não é tocado. O page_view automático do GA4 em navegação de SPA pode sair antes do `set`: não ponha segredo na URL.
- **Pixel da Meta:** o fbevents lê `location.href` sozinho e não há como sobrescrever. Por isso, em página cuja URL ou referrer precisa de limpeza, o Pixel **não carrega nem dispara** (a CAPI cobre o evento, pelo collect, com a URL limpa). Se o Pixel já estava carregado e a navegação de SPA leva a uma página assim, o módulo revoga o consentimento dele (`fbq('consent', 'revoke')`, a mesma regra da rota excluída); ao voltar a uma página limpa devolve o `grant` (descartando o que o fbevents capturou na revogação), mas só se o consentimento de marketing continua dado. Em desenvolvimento (`NODE_ENV` diferente de `production`) um `console.warn` explica. A loja não deve pôr segredo na URL de páginas onde o Pixel roda.
- **Limitação:** token no CAMINHO da URL (`/pedido/abc123`) não é coberto: só query e fragmento.

## Conversão confirmada vs tentativa (F7-11)

Para otimizar campanha, o evento que interessa é o **lead confirmado**, não a
tentativa. O contrato recomendado:

| Situação | Use | O evento representa |
|---|---|---|
| Formulário tradicional (navega no submit) | gatilho `formSubmit` no Admin | a TENTATIVA de envio; nomeie de acordo (ex.: `form_attempt`) |
| Formulário AJAX / React | `track('lead.enviado', …)` **no callback de sucesso** | lead aceito pelo frontend |
| Backend é a fonte de verdade (recomendado) | `trackServerEvent()` após persistir/validar | lead CONFIRMADO, com matching completo |

Server Action (App Router):

```ts
'use server'
import { getPayload } from 'payload'
import { createTrackingClient, readSubjectFromCookieHeader }
  from '@hiperbold/payload-tracking/server'
import { headers } from 'next/headers'

export async function enviarOrcamento(form: FormData) {
  const lead = await salvarLead(form) // sua regra de negócio decide o que é lead válido

  const subjectId = readSubjectFromCookieHeader((await headers()).get('cookie'))
  if (subjectId) {
    const payload = await getPayload({ config })
    await createTrackingClient(payload, trackingOptions).trackServerEvent(
      'lead.confirmado',
      { origem: 'form-orcamento' },
      { subjectId, user: { email: lead.email }, commerce: { value: lead.valor, currency: 'BRL', transactionId: lead.id } },
    )
  }
  return { ok: true }
}
```

Route handler é idêntico: leia o cookie do request, chame `trackServerEvent`
depois do sucesso. O Evento no Admin precisa de um gatilho do tipo `server`
com a mesma key. Frontend AJAX: chame `track()` só no caminho de sucesso da
resposta, nunca no `onSubmit`.

## Endpoints expostos

| Endpoint | Método | Cache | Papel |
|---|---|---|---|
| `{apiBase}/tracking/public-config` | GET | público, ETag/304 | config publicada (só IDs públicos, schema estrito na SAÍDA) |
| `{apiBase}/tracking/browser-token` | POST | `private, no-store` | origin → cookie selado → consentimento → token 300s |
| `{apiBase}/tracking/collect` | POST | — | corpo estrito, replay 409, rate limit, consentimento por destino |
| `{apiBase}/tracking/feed.xml` | GET | `cacheSegundos`, ETag/304 | feed de produtos (só com a opção `feed`; token opcional) |
| `/api/c15t/*` | * | — | backend c15t montado pelo consumidor (seção 3) |

## Notas por plataforma

- **Meta**: Pixel e CAPI recebem o MESMO `event_id`/`event_name` (dedup na Meta); enriquecimento (IP com `trustedProxies`, user-agent, `_fbp`/`_fbc` dos cookies da própria Meta) acontece no servidor e só no snapshot Meta; `test_event_code` por Tag valida no Test Events.
  - O navegador dispara com `fbq('trackSingle', pixelId, …)`, só para o Pixel do destino. `fbq('track')` iria a todos os Pixels da página, e o fbevents descarta o segundo PageView do mesmo documento, o que apagava o PageView das navegações de SPA.
  - O módulo desliga o PageView automático de navegação (`disablePushState`): o PageView é do dispatcher, com `eventID`.
  - Os eventos automáticos da Meta (`autoConfig`: cliques em botão, metadados da página) ficam no padrão da Meta, ligados. Saem só com consentimento de marketing, sem `eventID` e sem CAPI. O fbevents guarda os capturados durante uma revogação para enviar no `grant`; o módulo descarta esses eventos antes de conceder de novo.
  - A "correspondência avançada automática" do Events Manager lê campos de formulário na página. É configuração da conta, não do módulo; o módulo já manda e-mail e telefone hasheados de forma explícita no lead.
- **GA4**: caminhos EXCLUSIVOS: navegador só via gtag (Consent Mode v2 com default denied antes do config), servidor só via MP com `clientId` explícito. A exceção é a compra de loja virtual (Evento com tipo `purchase`): sai só pelo MP, a partir do `trackServerEvent` no webhook do pagamento (o collect não enfileira compra, D16). O GA4 não deduplica por `event_id`; os caminhos exclusivos evitam contagem dupla por construção.
  - Visualização de página é do próprio GA4 (`send_page_view: true` no `config` do `G-` e medição aprimorada nas navegações). Deixe ligada, no fluxo de dados, a opção "Mudanças de página com base em eventos do histórico do navegador" (padrão do GA4): desligada, as navegações internas não contam.
  - Revogar sem recarregar liga `window['ga-disable-G-…']`. Com o gtag.js já carregado, só o `consent update` não basta: a medição aprimorada continuaria mandando page_view sem cookie (`gcs=G100`).
- **Google Ads**: a compra de loja também sai pelo servidor (Data Manager API, deduplicada por `transaction_id`; ver "Google Ads pelo servidor"). Conversões no navegador com `send_to: AW-ID/LABEL` por destino; Enhanced Conversions só com dado explícito e consentido, hasheado antes do dataLayer (email em claro nunca aparece).
  - Enhanced Conversions só funciona em **HTTPS**. Em `http://localhost` o gtag manda `em=tv.1~ec.e3`, que é o código dele para "página sem HTTPS", e não é defeito.
  - **Desligue a detecção automática** de dados fornecidos pelo usuário nas configurações de conversões otimizadas da conta, quando o site usa o módulo. Ela procura e-mail na página: no piloto, mandou o e-mail de contato do rodapé do próprio site como se fosse do visitante, já na conversão de página.
  - Com o `config` do `AW-`, a Google tag manda um ping de página próprio (`ccm/collect … en=page_view`) no carregamento, mesmo com `send_page_view: false`. É sinal de remarketing do Google Ads, só sai depois do consentimento de marketing e não é conversão.
- **Instalação sempre em branco.** O site não pode ter Tag própria do Google ou da Meta (snippet de gtag, GTM com essas tags, Pixel colado no layout): o módulo reaproveita `gtag`/`fbq` que encontrar, e um `gtag` fora do formato oficial faz nenhum comando do módulo executar; um Pixel próprio com PageView automático conta cada navegação duas vezes. O plugin também não cria Tags nem Eventos: tudo começa vazio e é cadastrado no Admin de cada site, sem dado copiado de outro cliente.

## Verificação de rede (obrigatória antes de publicar)

Teste unitário e `dataLayer` não provam que o hit sai: a 1.1.0 passou em todos os gates sem nenhum disparo do Google chegar a sair. Antes de publicar uma versão, rode a verificação de rede contra um site com o pacote instalado (build de produção) e registre a saída. Procedimento completo em `docs/verificacao-de-rede.md`.

## Scripts do repositório

| Comando | Faz |
|---|---|
| `pnpm test:unit` / `pnpm test:integration` | 1567 unit · 366 integration (na 1.2.0) (integração exige o Postgres do `dev/`) |
| `node scripts/verificacao-rede/verificar.mjs <adaptador.json>` | verificação de rede com navegador real, envios finais bloqueados (`docs/verificacao-de-rede.md`) |
| `pnpm typecheck` / `pnpm lint` | estática |
| `pnpm build` | tipos por `tsc` + JS por SWC em `dist/` |
| `pnpm dev` | app dev completo (Admin + frontend E2E) na porta 3000 |
| `pnpm test:e2e` | aponta o procedimento E2E de navegador real (`docs/evidence/f6-e2e.md`) |

## Fora do escopo (decisões, não lacunas)

GTM como executor, regex livre em gatilhos, scanner de cookies, captura automática de PII do DOM, multi-tenancy numa instalação, Enhanced Conversions for Leads, audiências da Data Manager API (só a compra de loja usa a API) e frontends fora do App Router. Detalhes: plano, seção 12.
